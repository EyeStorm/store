<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//         $this->call([
//             CategorySeeder::class
//         ]);

//        DB::table('category')->truncate();
//        DB::table('category')->insert([
//            ['id' => 1, 'route' => 'Route01', 'name' => 'Menu01', 'parent_id' => 0],
//            ['id' => 2, 'route' => 'Route02', 'name' => 'Menu02', 'parent_id' => 0],
//            ['id' => 3, 'route' => 'Route03', 'name' => 'Menu03', 'parent_id' => 0],
//            ['id' => 4, 'route' => 'Route04', 'name' => 'Menu04', 'parent_id' => 1],
//            ['id' => 5, 'route' => 'Route05', 'name' => 'Menu05', 'parent_id' => 1],
//            ['id' => 6, 'route' => 'Route06', 'name' => 'Menu06', 'parent_id' => 2],
//            ['id' => 7, 'route' => 'Route07', 'name' => 'Menu07', 'parent_id' => 4],
//            ['id' => 8, 'route' => 'Route08', 'name' => 'Menu08', 'parent_id' => 4],
//            ['id' => 9, 'route' => 'Route09', 'name' => 'Menu09', 'parent_id' => 2],
//            ['id' => 10, 'route' => 'Route10', 'name' => 'Menu10', 'parent_id' => 1]
//        ]);
//
//        DB::table('post')->truncate();
//        factory(App\Models\Post::class, 100)->create();



        // Insert some category
        DB::table('category')->insert([
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'Tin tức',
                'class' => 0,
                'parent_id' => 0,
                'show_category_child' => 1
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'Dịch vụ',
                'class' => 0,
                'parent_id' => 0,
                'show_category_child' => 1
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'CÁP QUANG',
                'class' => 1,
                'parent_id' => 2,
                'show_category_child' => 0
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'TRUYỀN HÌNH CÁP',
                'class' => 1,
                'parent_id' => 2,
                'show_category_child' => 0
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'SẢN PHẨM & DỊCH VỤ',
                'class' => 1,
                'parent_id' => 2,
                'show_category_child' => 0
            )
        ]);

        // Insert some post
        DB::table('post')->insert([
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang gia đình',
                'content' => 'Cáp quang gia đình',
                'tags' => 'Cáp quang',
                'category_id' => 3,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang doanh nghiệp',
                'content' => 'Cáp quang doanh nghiệp',
                'tags' => 'Cáp quang',
                'category_id' => 3,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/2.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình cáp analog',
                'content' => 'Truyền hình cáp analog',
                'tags' => 'Truyền hình',
                'category_id' => 4,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/3.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 1 chiều',
                'content' => 'Truyền hình số 1 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 4,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/4.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 2 chiều',
                'content' => 'Truyền hình số 2 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 4,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/5.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Tivi box - Internettv',
                'content' => 'Tivi box - Internettv',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/6.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chữ ký số(Vietel - CA)',
                'content' => 'Chữ ký số(Vietel - CA)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/7.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => false,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            )
        ]);

        // Insert some slider
        DB::table('slider')->insert([
            array(
                'id' => 1,
                'image' => '/images/banners/survey-0005-mangviettelbinhduong_new.jpg',
                'title' => 'ĐĂNG KÝ SIM TRẢ SAU VIETTEL',
                'content' => 'Sim trả sau Viettel Bình Dương<br/>Tha hồ lựa chọn - Thủ tục đơn giản'
            ),
            array(
                'id' => 2,
                'image' => '/images/banners/survey-0002-mangviettelbinhduong_new.jpg',
                'title' => 'TRUYỀN HÌNH VIETTEL BÌNH DƯƠNG',
                'content' => 'Truyền hình Số - Truyền hình Nexttv<br/>Truyền hình cáp - CATV Viettel Bình Dương<br/>Hotline: 096 552 4224'
            ),
            array(
                'id' => 3,
                'image' => '/images/banners/chu_ky_so_viettel-_mang_viettel_binh_duong_2.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            ),
            array(
                'id' => 4,
                'image' => '/images/banners/chong_trom_xe_may_viettel_mang_viettel_binh_duong.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            ),
            array(
                'id' => 5,
                'image' => '/images/banners/survey-0009-mangviettelbinhduong_new.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            ),
            array(
                'id' => 6,
                'image' => '/images/banners/survey-0008-mangviettelbinhduong_new.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            )
        ]);

        // Insert some advertisement
        DB::table('advertisement')->insert([
            array(
                'id' => '1',
                'title' => '/images/newfeed/1.gif',
                'img_path' => '/images/newfeed/1.gif',
                'links' => 'http://localhost:8000/service_detail?id=1'
            ),
            array(
                'id' => '2',
                'title' => '/images/newfeed/2.jpg',
                'img_path' => '/images/newfeed/2.jpg',
                'links' => 'http://localhost:8000/service_detail?id=2'
            ),
            array(
                'id' => '3',
                'title' => '/images/newfeed/3.jpg',
                'img_path' => '/images/newfeed/3.jpg',
                'links' => 'http://localhost:8000/service_detail?id=3'
            )
        ]);

        // Insert some news
        DB::table('post')->insert([
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang gia đình',
                'content' => 'Cáp quang gia đình',
                'tags' => 'Cáp quang',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/1.jpg'
            ), array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang doanh nghiệp',
                'content' => 'Cáp quang doanh nghiệp',
                'tags' => 'Cáp quang',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/2.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình cáp analog',
                'content' => 'Truyền hình cáp analog',
                'tags' => 'Truyền hình',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/3.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 1 chiều',
                'content' => 'Truyền hình số 1 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/4.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 2 chiều',
                'content' => 'Truyền hình số 2 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/5.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Tivi box - Internettv',
                'content' => 'Tivi box - Internettv',
                'tags' => 'Sản phẩm',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/6.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chữ ký số(Vietel - CA)',
                'content' => 'Chữ ký số(Vietel - CA)',
                'tags' => 'Sản phẩm',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/7.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            )
        ]);
    }
}
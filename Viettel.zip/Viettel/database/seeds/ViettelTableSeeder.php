<?php

use Illuminate\Database\Seeder;

class ViettelTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Insert some category
        DB::table('category')->insert([
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'Tin tức',
                'class' => 0,
                'parent_id' => 0,
                'show_category_child' => 1
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'Dịch vụ',
                'class' => 0,
                'parent_id' => 0,
                'show_category_child' => 1
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'CÁP QUANG',
                'class' => 1,
                'parent_id' => 2,
                'show_category_child' => 0
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'TRUYỀN HÌNH CÁP',
                'class' => 1,
                'parent_id' => 2,
                'show_category_child' => 0
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'name' => 'SẢN PHẨM & DỊCH VỤ',
                'class' => 1,
                'parent_id' => 2,
                'show_category_child' => 0
            )
        ]);

        // Insert some post
        DB::table('post')->insert([
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang gia đình',
                'content' => 'Cáp quang gia đình',
                'tags' => 'Cáp quang',
                'category_id' => 3,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/1.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang doanh nghiệp',
                'content' => 'Cáp quang doanh nghiệp',
                'tags' => 'Cáp quang',
                'category_id' => 3,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/2.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình cáp analog',
                'content' => 'Truyền hình cáp analog',
                'tags' => 'Truyền hình',
                'category_id' => 4,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/3.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 1 chiều',
                'content' => 'Truyền hình số 1 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 4,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/4.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 2 chiều',
                'content' => 'Truyền hình số 2 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 4,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/5.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Tivi box - Internettv',
                'content' => 'Tivi box - Internettv',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/6.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chữ ký số(Vietel - CA)',
                'content' => 'Chữ ký số(Vietel - CA)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/7.jpg'
            ),
            array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chống trộm xe máy (Smart motor viettel)',
                'content' => 'Chống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 5,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            )
        ]);

        // Insert some slider
        DB::table('slider')->insert([
            array(
                'id' => 1,
                'image' => '/images/banners/survey-0005-mangviettelbinhduong_new.jpg',
                'title' => 'ĐĂNG KÝ SIM TRẢ SAU VIETTEL',
                'content' => 'Sim trả sau Viettel Bình Dương<br/>Tha hồ lựa chọn - Thủ tục đơn giản'
            ),
            array(
                'id' => 2,
                'image' => '/images/banners/survey-0002-mangviettelbinhduong_new.jpg',
                'title' => 'TRUYỀN HÌNH VIETTEL BÌNH DƯƠNG',
                'content' => 'Truyền hình Số - Truyền hình Nexttv<br/>Truyền hình cáp - CATV Viettel Bình Dương<br/>Hotline: 096 552 4224'
            ),
            array(
                'id' => 3,
                'image' => '/images/banners/chu_ky_so_viettel-_mang_viettel_binh_duong_2.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            ),
            array(
                'id' => 4,
                'image' => '/images/banners/chong_trom_xe_may_viettel_mang_viettel_binh_duong.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            ),
            array(
                'id' => 5,
                'image' => '/images/banners/survey-0009-mangviettelbinhduong_new.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            ),
            array(
                'id' => 6,
                'image' => '/images/banners/survey-0008-mangviettelbinhduong_new.jpg',
                'title' => 'DỊCH VỤ CHỮ KÝ SỐ VIETTEL CA',
                'content' => 'Viettel CA Bình Dương<br/>- Phát hành chữ ký số<br/>- Gia hạn, thay đổi, phục hồi'
            )
        ]);

        // Insert some advertisement
        DB::table('advertisement')->insert([
            array(
                'id' => '1',
                'img_path' => '/images/newfeed/1.gif',
                'post_id' => '1'
            ),
            array(
                'id' => '2',
                'img_path' => '/images/newfeed/2.jpg',
                'post_id' => '2'
            ),
            array(
                'id' => '3',
                'img_path' => '/images/newfeed/3.jpg',
                'post_id' => '3'
            )
        ]);

        // Insert some news
        DB::table('post')->insert([
              array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang gia đình',
                'content' => 'Cáp quang gia đình',
                'tags' => 'Cáp quang',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/1.jpg'
            ), array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Cáp quang doanh nghiệp',
                'content' => 'Cáp quang doanh nghiệp',
                'tags' => 'Cáp quang',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/2.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình cáp analog',
                'content' => 'Truyền hình cáp analog',
                'tags' => 'Truyền hình',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/3.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 1 chiều',
                'content' => 'Truyền hình số 1 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/4.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Truyền hình số 2 chiều',
                'content' => 'Truyền hình số 2 chiều',
                'tags' => 'Truyền hình',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/5.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Tivi box - Internettv',
                'content' => 'Tivi box - Internettv',
                'tags' => 'Sản phẩm',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/6.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Chữ ký số(Vietel - CA)',
                'content' => 'Chữ ký số(Vietel - CA)',
                'tags' => 'Sản phẩm',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/7.jpg'
            ),array(
                'created_at' => date("Y-m-d H:i:s"),
                'updated_at' => date("Y-m-d H:i:s"),
                'deleted_at' => null,
                'title' => 'Trống trộm xe máy (Smart motor viettel)',
                'content' => 'Trống trộm xe máy (Smart motor viettel)',
                'tags' => 'Sản phẩm',
                'category_id' => 1,
                'is_top' => true,
                'icon_path' => '/images/serviceInfo/sub1.jpg'
            )
        ]);
    }
}

<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/'              ,'HomeController@index')    ->name('home.index');
Route::get('/service_detail','HomeController@detail')   ->name('home.detail');
Route::get('/contact'       ,'HomeController@contact')  ->name('home.contact');
Route::get('/news'          ,'NewsController@index')    ->name('news.index');
Route::get('/news_detail'   ,'NewsController@detail')   ->name('news.detail');




Route::get('/qRlry9HpU7Wv8wrpKLxTBYZgDJM6iGYa8NYJA', 'AdminController@index')->name('admin.index');
// Menu
Route::prefix('menus')->group(function () {
    Route::put('update'     ,'CategoryController@update')   ->name('menus.update');
    Route::put('{id?}'      ,'CategoryController@restore')  ->name('menus.restore');
    Route::delete('{id?}'   ,'CategoryController@delete')   ->name('menus.delete');
});
// Slider
Route::prefix('slider')->group(function () {
    //Route::post('save'     ,'SliderController@save')      ->name('slider.save');
    Route::put('update'    ,'SliderController@update')    ->name('slider.update');
    Route::put('{id?}'     ,'SliderController@restore')   ->name('slider.restore');
    Route::delete('{id?}'  ,'SliderController@delete')    ->name('slider.delete');
});
// Post
Route::prefix('post')->group(function () {
    Route::get('{id?}'      ,'PostController@get')    ->name('post.get');
    Route::post('save'      ,'PostController@save')   ->name('post.save');
    Route::put('{id?}'      ,'PostController@restore')->name('post.restore');
    Route::delete('{id?}'   ,'PostController@delete') ->name('post.delete');
});
Route::prefix('posts')->group(function () {
    Route::get('route/{id?}','PostController@byRoute')   ->name('posts.route.list');
});
// Advisory
Route::prefix('advisory')->group(function () {
    Route::post(''         ,'AdvisoryController@create')   ->name('advisory.create');
    Route::put('{id?}'     ,'AdvisoryController@restore')  ->name('advisory.restore');
    Route::delete('{id?}'  ,'AdvisoryController@delete')   ->name('advisory.delete');
    //
    Route::put('action/{id?}'    ,'AdvisoryController@doAdvised')   ->name('advisory.do.advised');
});
Route::prefix('advisories')->group(function () {
    Route::get('{date?}'    ,'AdvisoryController@byDate')   ->name('advisory.date.list');
});
// Advertisement
Route::prefix('newfeed')->group(function () {
    Route::post('save'     ,'AdvertisementController@save')    ->name('advertisement.save');
    Route::put('update'    ,'AdvertisementController@update')  ->name('advertisement.update');
    Route::put('{id?}'     ,'AdvertisementController@restore') ->name('advertisement.restore');
    Route::delete('{id?}'  ,'AdvertisementController@delete')  ->name('advertisement.delete');
});

Route::get('/foo', function () {
    Artisan::call('migrate');
});
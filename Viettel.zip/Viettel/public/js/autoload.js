//
//  Load common file
//

const list_js_file = [
     'constants.js'
    ,'constants.model.name.js'
    ,'common.js'
    ,'common.ajax.js'
    ,'common.func.js'
    ,'plugins/isOnScreen.js'
    ,'common.menu.bar.js'
];

list_js_file.forEach(function($file) {
    if ( $file === "" || $("script[src='"+$file+"']").length > 0) {
        return false;
    }
    $file = "js/" + $file;
    let script = document.createElement('script');
    script.async = true;
    script.type = 'text/javascript';
    script.src = $file;
    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(script);
});




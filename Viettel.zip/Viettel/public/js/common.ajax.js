
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

// $(document).ajaxStart(function (event, XMLHttpRequest, ajaxOptions) {
//     console.log(event);
//     console.log(XMLHttpRequest);
//     console.log(ajaxOptions);
// });
//
// $(document).ajaxStop(function (event) {
//     console.log(event);
// });
//
// $(document).ajaxComplete(function (event, XMLHttpRequest, ajaxOptions) {
//     console.log(event);
//     console.log(XMLHttpRequest);
//     console.log(ajaxOptions);
// });
//
$(document).ajaxError(function (event, XMLHttpRequest, ajaxOptions) {
    // console.log(event);
    // console.log(XMLHttpRequest);
    // console.log(ajaxOptions);
    if ( ajaxOptions.type !== "GET") {
        alert("Đã có lỗi xảy ra ! \nVui lòng liên hệ người quản lý !");
    }
});
//
// $(document).ajaxSuccess(function (event, XMLHttpRequest, ajaxOptions) {
//     console.log(event);
//     console.log(XMLHttpRequest);
//     console.log(ajaxOptions);
// });
//
// $(document).ajaxSend(function (event, XMLHttpRequest, ajaxOptions) {
//     console.log(event);
//     console.log(XMLHttpRequest);
//     console.log(ajaxOptions);
// });



function defaultImage($path) {
    switch ($path){
        case undefined:
        case "":
            $path = POST_NO_IMAGE;
    }
    return $path;
}
$.fn.isOnScreen = function(partial){

    //let's be sure we're checking only one element (in case function is called on set)
    let t = $(this).first();

    //we're using getBoundingClientRect to get position of element relative to viewport
    //so we dont need to care about scroll position
    let box = t[0].getBoundingClientRect();

    //let's save window size
    let win = {
        h : $(window).height(),
        w : $(window).width()
    };

    //now we check against edges of element

    //firstly we check one axis
    //for example we check if left edge of element is between left and right edge of scree (still might be above/below)
    let topEdgeInRange = box.top >= 0 && box.top <= win.h;
    let bottomEdgeInRange = box.bottom >= 0 && box.bottom <= win.h;

    let leftEdgeInRange = box.left >= 0 && box.left <= win.w;
    let rightEdgeInRange = box.right >= 0 && box.right <= win.w;


    //here we check if element is bigger then window and 'covers' the screen in given axis
    let coverScreenHorizontally = box.left <= 0 && box.right >= win.w;
    let coverScreenVertically = box.top <= 0 && box.bottom >= win.h;

    //now we check 2nd axis
    let topEdgeInScreen = topEdgeInRange && ( leftEdgeInRange || rightEdgeInRange || coverScreenHorizontally );
    let bottomEdgeInScreen = bottomEdgeInRange && ( leftEdgeInRange || rightEdgeInRange || coverScreenHorizontally );

    let leftEdgeInScreen = leftEdgeInRange && ( topEdgeInRange || bottomEdgeInRange || coverScreenVertically );
    let rightEdgeInScreen = rightEdgeInRange && ( topEdgeInRange || bottomEdgeInRange || coverScreenVertically );

    //now knowing presence of each edge on screen, we check if element is partially or entirely present on screen
    let isPartiallyOnScreen = topEdgeInScreen || bottomEdgeInScreen || leftEdgeInScreen || rightEdgeInScreen;
    let isEntirelyOnScreen = topEdgeInScreen && bottomEdgeInScreen && leftEdgeInScreen && rightEdgeInScreen;

    return partial ? isPartiallyOnScreen : isEntirelyOnScreen;

};

$.expr.filters.onscreen = function(elem) {
    return $(elem).isOnScreen(true);
};

$.expr.filters.entireonscreen = function(elem) {
    return $(elem).isOnScreen(true);
};

/*
$("header").filter(":onscreen").doSomething();
$("header").filter(":entireonscreen").doSomething();
$("header").isOnScreen(); // true / false
$("header").isOnScreen(true); // true / false (partially on screen)
$("header").is(":onscreen"); // true / false (partially on screen)
$("header").is(":entireonscreen"); // true / false
*/
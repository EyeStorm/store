const POST_NO_IMAGE = "/images/default/post_no_image.jpg";
const ON_ERROR_IMAGE = "/images/default/on_error_image.jpg";
$(document).ready(function () {
    $("nav")
    .on("mouseenter", function() {
        showMenu();
    })
    .on("mouseleave", function() {
        hideMenu();
    });

    $(".menu-btn").on("click", function () {
        if ($(this).hasClass("onShow")) {
            hideMenu();
        } else {
            showMenu();
        }
    });

    $(".expand").on("click", function () {
        if ($(".menu-btn").length > 0 && $(".menu-btn").css("display") === "none") {
            return;
        }
        $(this).parents("li.expand").addClass("not-allow");
        if ($(this).hasClass("not-allow")) {
            $(this).removeClass("not-allow");
            return;
        }
        $(this).find(">ul").toggleClass("expanded");
        $(this).find(">a").toggleClass("expanded");
    });

});

function showMenu() {
    $("nav").addClass("show");
    $(".menu-btn").addClass("onShow");
}
function hideMenu() {
    $("nav").removeClass("show");
    $(".expanded").toggleClass("expanded");
    $(".menu-btn").removeClass("onShow");
}

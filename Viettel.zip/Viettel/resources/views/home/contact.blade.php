@extends('base.master', ['aryCategory' => $aryCategory])

{{----}}
@section('css')

@endsection

{{----}}
@section('js')
<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBFSWCfPAYLm0NhlpaUVcUPie_XkztAOok"></script>
<script src="{{ asset('vendor/gmap/gmaps.js') }}"></script>
<script type="text/javascript">
$(document).ready(function(){
    let $locations = {
        'thu-dau-mot' : {
            lat : 10.9816115,
            lng : 106.656396,
            title: 'TỔNG ĐÀI INTERNET VIETTEL BÌNH DƯƠNG - Thủ dầu một',
            content: '<h4>Thủ Dầu Một, Tỉnh Bình Dương</h4>'
        },
        'thuan-an' : {
            lat : 10.9816115,
            lng : 106.656396,
            title: 'TỔNG ĐÀI INTERNET VIETTEL BÌNH DƯƠNG - Thuận An',
            content: '<h4>Thuận An, Tỉnh Bình Dương</h4>'
        },
        'di-an' : {
            lat : 10.9816115,
            lng : 106.656396,
            title: 'TỔNG ĐÀI INTERNET VIETTEL BÌNH DƯƠNG - Dĩ An',
            content: '<h4>Dĩ An, Tỉnh Bình Dương</h4>'
        },
        'ben-cat' : {
            lat : 10.9816115,
            lng : 106.656396,
            title: 'TỔNG ĐÀI INTERNET VIETTEL BÌNH DƯƠNG - Bến Cát',
            content: '<h4>Bến Cát, Tỉnh Bình Dương</h4>'
        },
        'tan-uyen' : {
            lat : 10.9816115,
            lng : 106.656396,
            title: 'TỔNG ĐÀI INTERNET VIETTEL BÌNH DƯƠNG - Tân Uyên',
            content: '<h4>Tân Uyên, Tỉnh Bình Dương</h4>'
        }
    };

    let $location = $locations['{{$location}}'];
    if ( $location === undefined ) {
        $location = $locations['thu-dau-mot'];
    }
    map = new GMaps({
        div: '#map',
        lat: $location.lat,
        lng: $location.lng
    });
    map.addMarker({
        lat: $location.lat,
        lng: $location.lng,
        title: $location.title,
        infoWindow: {
            content: $location.content
        }
    });
    infoWindow = map.markers[0].infoWindow;
    infoWindow.open(map.map, map.markers[0]);
});
</script>
@endsection

{{----}}
@section('content')

<div class="w3-content">
<!-- Grid -->
<div class="w3-row">

<!-- Contact -->
<div class="w3-col">
    <!-- Service information -->
    <div>
        <div class="w3-container contact-h4">
            <h4>Liên hệ</h4>
        </div>
    <!-- Contact-->
    <div class="w3-row-padding">
        <div class="w3-half w3-container w3-margin-bottom">
           @include('component.form-regist.advisory')
        </div>
        <div class="w3-half w3-container w3-margin-bottom">
            <div class="contact-div">
                <p><h3>TỔNG ĐÀI INTERNET VIETTEL BÌNH DƯƠNG</h3></p>
                <p>
                <h5>Điện thoại:
                    <span class="phone">
                        <a href="tel:01627449999" class="none-decoration phone">01627449999</a>
                        -
                        <a href="tel:0979125678" class="none-decoration phone">0979125678</a>
                    </span>
                </h5>
                </p>
                <p><h5>Khu vực hỗ trợ: <span class="address">Thủ Dầu Một, Thuận An, Dĩ An, Bến Cát, Tân Uyên</span> </h5></p>
            </div>
        </div>
    </div>
    
    <!-- Map-->
    <div class="w3-row-padding">
        <div id="map">
        </div>
    </div>
    <hr>
 
<!-- END CONTACT -->
</div>

<!-- END GRID -->
</div><br>
</div>

<!-- END w3-content -->
</div>

@endsection

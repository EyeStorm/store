@extends('base.master')

@section('css')
@endsection

@section('js')
@endsection

@section('content')
    <!-- w3-content defines a container for fixed size centered content,
and is wrapped around the whole page content, except for the footer in this example -->
<div class="w3-content">
<!-- Grid -->
<div class="w3-row">

<!-- Home -->
<div class="w3-col l8 s12">
    <!-- Service information -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Thông tin dịch vụ</h4>
        </div>
        <!-- Services Grid-->
        @for ($i = 0; $i < count($aryServices); $i++)
            @if ($i%3 == 0)
            <div class="w3-row-padding">
            @endif
                <div class="w3-third w3-container w3-margin-bottom">
                    <a href='{{route("home.detail", ["id" => $aryServices[$i]->id])}}'>
                        <img src="{{ asset($aryServices[$i]->icon_path) }}" alt="{{$aryServices[$i]->title}}" style="width:100%" class="w3-hover-opacity">
                    </a>
                    <div class="div-service w3-white">
                        <p><b>{{ $aryServices[$i]->title }}</b></p>
                        <p>{{ strlen($aryServices[$i]->short_content) < 99? $aryServices[$i]->short_content: substr($aryServices[$i]->short_content, 0, strpos($aryServices[$i]->short_content, " ", 100)?strpos($aryServices[$i]->short_content, " ", 100): 100) . '…' }}</p>
                        <div class="w3-row">
                            <div class="w3-col m8 s12">
                                <p><a class="w3-button w3-padding-small w3-white w3-border" href='{{route("home.detail", ["id" => $aryServices[$i]->id])}}'><b>Xem thêm &raquo;</b></a></p>
                            </div>
                        </div>
                    </div>
                </div>
            @if ($i%3 == 2 || $i == count($aryServices) - 1)
            </div>
            @endif
        @endfor
        <div class="w3-center">
            <!-- Pagination -->
            <div class="w3-center w3-padding-32">
                <div class="w3-bar">
                    <a href="{{ $aryServices->url(1) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryServices->currentPage() == 1) ? ' disabled' : '' }}">«</a>
                    @for ($i = 1; $i <= $aryServices->lastPage(); $i++)
                        <?php
                        $half_total_links = floor(7 / 2);
                        $from = $aryServices->currentPage() - $half_total_links;
                        $to = $aryServices->currentPage() + $half_total_links;
                        if ($aryServices->currentPage() < $half_total_links) {
                           $to += $half_total_links - $aryServices->currentPage();
                        }
                        if ($aryServices->lastPage() - $aryServices->currentPage() < $half_total_links) {
                            $from -= $half_total_links - ($aryServices->lastPage() - $aryServices->currentPage()) - 1;
                        }
                        ?>
                        @if ($from < $i && $i < $to)
                            <a href="{{ $aryServices->url($i) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryServices->currentPage() == $i)? ' w3-theme' : '' }}">{{ $i }}</a>
                        @endif
                    @endfor
                    <a href="{{ $aryServices->url($aryServices->lastPage()) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryServices->currentPage() == $aryServices->lastPage()) ? ' disabled' : '' }}">»</a>
                </div>
            </div>
        </div>
    </div>
    <hr>

    <!-- News -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container bottom-margin-none">
            <h4>Tin tức</h4>
        </div>
        <div class="w3-row-padding">
            <div class="w3-half">
                <div class="w3-white">
                    @if (count($aryNewsTop) > 0)
                        <ul class="w3-ul w3-white">
                            <a class="none-decoration" href="{{ route('news.detail', ['id' => $aryNewsTop[0]->id]) }}">
                                <li class="w3-padding-16">
                                    <img src="{{ asset($aryNewsTop[0]->icon_path) }}" alt="Norway" style="width:40%" class="w3-left w3-margin-right">
                                    <span class="w3-large">{{$aryNewsTop[0]->title}}</span>
                                    <br>
                                    <p class="w3-text-grey text-justify">{{ strlen($aryNewsTop[0]->short_content) < 800? $aryNewsTop[0]->short_content : substr($aryNewsTop[0]->short_content, 0, strpos($aryNewsTop[0]->short_content, " ", 800)?strpos($aryNewsTop[0]->short_content, " ", 800): 800) . '…' }}</p>
                                </li>
                            </a>
                        </ul>
                    @endif
                 </div>
            </div>
            <div class="w3-half">
                <div class="w3-white">
                    <ul class="w3-ul w3-hoverable w3-white">
                        @for ($i = 1; $i < count($aryNewsTop); $i++)
                            <a class="none-decoration" href="{{ route('news.detail', ['id' => $aryNewsTop[$i]->id]) }}">
                                <li class="w3-padding-16">
                                    <img src="{{ asset($aryNewsTop[$i]->icon_path) }}" alt="{{ $aryNewsTop[$i]->title }}" class="w3-left w3-margin-right" style="width:50px">
                                    <span class="w3-large">{{ $aryNewsTop[$i]->title }}</span>
                                    <br>
                                    <span class="w3-text-grey">{{ strlen($aryNewsTop[$i]->short_content) < 99? $aryNewsTop[$i]->short_content : substr($aryNewsTop[$i]->short_content, 0, strpos($aryNewsTop[$i]->short_content, " ", 100)?strpos($aryNewsTop[$i]->short_content, " ", 100): 100) . '…' }}</span>
                                </li>
                            </a>
                        @endfor
                    </ul>
                </div>
            </div>
        </div>
    </div>
<!-- END HOME -->
</div>

<!-- Introduction menu -->
<div class="w3-col l4">
    <!-- About Card and Subscribe -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Liên hệ chúng tôi</h4>
        </div>
        <div class="div-contact">
            <div class="div-inline-block contact-phone">
                <a href="tel:0961264666" class="none-decoration" style="float:left"><i class="fa fa-phone fa-fw w3-xxlarge"></i></a>
                <div class="list-phone">
                    <p>Admin1 : <a href="tel:01627449999" class="none-decoration phone">01627449999</a></p>
                    <p>Admin2 : <a href="tel:0979125678" class="none-decoration phone">0979125678</a></p>
                </div>
            </div>


            {{--<p class="map-location">--}}
                {{--<a href="{{ route('home.contact') }}?thu-dau-mot" class="none-decoration">--}}
                    {{--<i class="fa fa-map-marker fa-fw w3-xxlarge"></i>Thủ Dầu Một--}}
                {{--</a>--}}
                {{--<a href="{{ route('home.contact') }}?thuan-an" class="none-decoration">, Thuận An</a>--}}
                {{--<a href="{{ route('home.contact') }}?di-an" class="none-decoration">, Dĩ An</a>--}}
                {{--<a href="{{ route('home.contact') }}?ben-cat" class="none-decoration">, Bến Cát</a>--}}
                {{--<a href="{{ route('home.contact') }}?tan-uyen" class="none-decoration">, Tân Uyên</a>--}}
            {{--</p>--}}

            {{--<p><i class="fa fa-envelope fa-fw w3-xxlarge"></i> mangviettelbinhduong@gmail.com</p>--}}
            @include('component.form-regist.advisory')
        </div>
    </div>
    <hr>
 
    <!-- Advertise -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            @foreach ($aryAdvertisement as $objAdvertisement)
                <a href="{{ route('home.detail', ['id' => $objAdvertisement->post_id]) }}">
                    <img class="w3-image img-advertise" src="{{ asset($objAdvertisement->img_path) }}">
                </a>
            @endforeach
        </div>
    </div>
    
<!-- END Introduction Menu -->
</div>

<!-- END GRID -->
</div><br>

<!-- END w3-content -->
</div>

@endsection

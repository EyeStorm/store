@extends('base.master')

@section('css')
@endsection

@section('js')
@endsection

@section('content')
<div class="w3-content">
<!-- Grid -->
<div class="w3-row">

<!-- Entries -->
<div class="w3-col l8 s12">
    <!-- Service information -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>
            @if ($aryService != null)
                {!! $aryService->title !!}
            @endif
            </h4>
        </div>
        <!-- Contents-->
        <div class="w3-row-padding">
            <div class="w3-container w3-margin-bottom">
            @if ($aryService != null)
                {!! $aryService->content !!}
            @endif
            </div>
        </div>
    </div>
    <hr>

    <!-- Register -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container bottom-margin-none">
            <h4>Đăng ký tư vấn</h4>
        </div>
        <div class="w3-row-padding">
            <div class="w3-twothird">
                @include('component.form-regist.advisory')
            </div>
            <div class="w3-third w3-center w3-padding-16">
                <img src="{{ asset('images/newfeed/support.jpg') }}" alt="Norway" style="width:100%" class="w3-hover-opacity">
            </div>
        </div>
    </div>

    <!-- Other services -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container bottom-margin-none">
            <h4>Dịch vụ khác</h4>
        </div>
        <div class="w3-row-padding div-other-service">
            @for ($i = 0; $i < count($aryOther); $i++)
                @if ($i%2 == 0)
                <div class="w3-half">
                @endif
                    <div class="w3-row-padding">
                        <div class="w3-third w3-center w3-padding-16">
                            <a href='{{route("home.detail", ["id" => $aryOther[$i]->id])}}'>
                                <img src="{{ asset($aryOther[$i]->icon_path) }}" alt="{{$aryOther[$i]->title}}" style="width:100%" class="w3-hover-opacity">
                            </a>
                        </div>
                        <div class="w3-twothird w3-padding-16">
                            <a class="none-decoration" href='{{route("home.detail", ["id" => $aryOther[$i]->id])}}'>
                                <h4>{{ $aryOther[$i]->title }}</h4>
                            </a>
                            <p class="w3-text-grey">{{ strlen($aryOther[$i]->short_content) < 99? $aryOther[$i]->short_content : substr($aryOther[$i]->short_content, 0, strpos($aryOther[$i]->short_content, " ", 100)?strpos($aryOther[$i]->short_content, " ", 100): 100) . '…' }}</p>
                        </div>
                    </div>
                @if ($i%2 == 1 || $i == count($aryOther) - 1)
                </div>
                @endif
            @endfor
        </div>
    </div>
<!-- END ENTRIES -->
</div>

<!-- Introduction Menu -->
<div class="w3-col l4">
    <!-- New services -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Dự án mới</h4>
        </div>
        <div class="padding-15">
            <div class="w3-white">
                <ul class="w3-ul w3-hoverable w3-white">
                    @foreach ($aryServicesTop as $objServices)
                    <a class="none-decoration" href="{{ route('home.detail', ['id' => $objServices->id]) }}">
                        <li class="w3-padding-16">
                            <img src="{{ asset($objServices->icon_path) }}" alt="{{$objServices->title}}" class="w3-left w3-margin-right" style="width:50px">
                            <span class="w3-large">{{$objServices->title}}</span>
                            <br>
                            <span class="w3-text-grey">{{ strlen($objServices->short_content) < 99? $objServices->short_content : substr($objServices->short_content, 0, strpos($objServices->short_content, " ", 100)?strpos($objServices->short_content, " ", 100): 100) . '…' }}</span>
                        </li>
                    </a>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
    <!-- News -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Bài viết mới</h4>
        </div>
        <div class="padding-15">
            <div class="w3-white">
                <ul class="w3-ul w3-hoverable w3-white">
                    @foreach ($aryNewsTop as $objNews)
                    <a class="none-decoration" href="{{ route('home.detail', ['id' => $objNews->id]) }}">
                        <li class="w3-padding-16">
                            <img src="{{ asset($objNews->icon_path) }}" alt="{{$objNews->title}}" class="w3-left w3-margin-right" style="width:50px">
                            <span class="w3-large">{{$objNews->title}}</span>
                            <br>
                            <span class="w3-text-grey">{{ strlen($objNews->short_content) < 99? $objNews->short_content : substr($objNews->short_content, 0, strpos($objNews->short_content, " ", 100)?strpos($objNews->short_content, " ", 100): 100) . '…' }}</span>
                        </li>
                    </a>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
    <hr>
 
    <!-- Advertise -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            @foreach ($aryAdvertisement as $objAdvertisement)
                <a href="{{$objAdvertisement->links}}">
                    <img class="w3-image img-advertise" src="{{ asset($objAdvertisement->img_path) }}">
                </a>
            @endforeach
        </div>
    </div>
<!-- END Introduction Menu -->
</div>

<!-- END GRID -->
</div><br>

<!-- END w3-content -->
</div>

@endsection

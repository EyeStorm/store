@extends('base.master')

{{----}}
@section('css')
@endsection

{{----}}
@section('js')
@endsection

{{----}}
@section('content')

    <!-- w3-content defines a container for fixed size centered content,
and is wrapped around the whole page content, except for the footer in this example -->
<div class="w3-content">
<!-- Grid -->
<div class="w3-row">

<!-- Entries -->
<div class="w3-col l8 s12">
    <!-- News information -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>
            @if ($aryNews != null)
                {!! $aryNews[0]->title !!}
            @endif
            </h4>
        </div>
        <!-- Content-->
        <div class="w3-row-padding">
            <div class="w3-container w3-margin-bottom">
            @if ($aryNews != null)
                {!! $aryNews[0]->content !!}
            @endif
            </div>
        </div>
    </div>
    <hr>
    <!-- Old information -->
    <div>
        <div class="w3-padding inline-container">
            <h4>Bài viết cũ hơn</h4>
        </div>
        <!-- First Photo Grid-->
        <div class="w3-row-padding">
            <div class="w3-container">
                @foreach ($aryOther as $objNews)
                    <a class="none-decoration hover-blue" href="{{ route('news.detail', ['id' => $objNews->id]) }}">
                        <li class="w3-padding-8">
                            <span class="w3-large">{{$objNews->title}}</span>
                        </li>
                    </a>
                @endforeach
            </div>
        </div>
    </div>
    <hr>
<!-- END ENTRIES -->
</div>

<!-- Introduction Menu -->
<div class="w3-col l4">
    <!-- New services -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Dự án mới</h4>
        </div>
        <div class="padding-15">
            <div class="w3-white">
                <ul class="w3-ul w3-hoverable w3-white">
                    @foreach ($aryServicesTop as $objServices)
                    <a class="none-decoration" href="{{ route('home.detail', ['id' => $objServices->id]) }}">
                        <li class="w3-padding-16">
                            <img src="{{ asset($objServices->icon_path) }}" alt="{{$objServices->title}}" class="w3-left w3-margin-right" style="width:50px">
                            <span class="w3-large">{{$objServices->title}}</span>
                            <br>
                            <span class="w3-text-grey">{{ strlen($objServices->short_content) < 99? $objServices->short_content : substr($objServices->short_content, 0, strpos($objServices->short_content, " ", 100)?strpos($objServices->short_content, " ", 100): 100) . '…' }}</span>
                        </li>
                    </a>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
    <!-- News -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Bài viết mới</h4>
        </div>
        <div class="padding-15">
            <div class="w3-white">
                <ul class="w3-ul w3-hoverable w3-white">
                    @foreach ($aryNewsTop as $objNews)
                    <a class="none-decoration" href="{{ route('home.detail', ['id' => $objNews->id]) }}">
                        <li class="w3-padding-16">
                            <img src="{{ asset($objNews->icon_path) }}" alt="{{$objNews->title}}" class="w3-left w3-margin-right" style="width:50px">
                            <span class="w3-large">{{$objNews->title}}</span>
                            <br>
                            <span class="w3-text-grey">{{ strlen($objNews->short_content) < 99? $objNews->short_content : substr($objNews->short_content, 0, strpos($objNews->short_content, " ", 100)?strpos($objNews->short_content, " ", 100): 100) . '…' }}</span>
                        </li>
                    </a>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
    <hr>
 
    <!-- Advertise -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            @foreach ($aryAdvertisement as $objAdvertisement)
                <a href="{{ route('home.detail', ['id' => $objAdvertisement->post_id]) }}">
                    <img class="w3-image img-advertise" src="{{ asset($objAdvertisement->img_path) }}">
                </a>
            @endforeach
        </div>
    </div>
<!-- END Introduction Menu -->
</div>

<!-- END GRID -->
</div><br>

<!-- END w3-content -->
</div>

@endsection

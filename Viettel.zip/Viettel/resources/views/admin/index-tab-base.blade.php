
{{----}}
<section id="{{ $id }}" class='{{ $class }} tab-content' >

    {{-- Content all area --}}
    @Using($contentBoth)
        {{ $contentBoth }}
    @endUsing

    {{-- Content Left --}}
    @Using($contentLeft)
        <div class="content-left">{{ $contentLeft }}</div>
    @endUsing

    {{-- Content Right --}}
    @Using($contentRight)
        <div class="content-right">{{ $contentRight }}</div>
    @endUsing

    {{-- DOM event--}}
    {{ $domEventScript }}

    {{-- Function JS--}}
    {{ $funcScript }}

</section>
{{--
@component('admin.index-tab-base')

    @slot('id')
    @endslot

    @slot('class')
    @endslot

    @slot('contentBoth')
    @endslot

    @slot('contentLeft')
    @endslot

    @slot('contentRight')
    @endslot

    @slot('domEventScript')
    @endslot

    @slot('funcScript')
    @endslot

@endcomponent
--}}

@foreach ($posts as $key=>$post)
    <tr
        data-post-id="{{$post->id}}"
        data-post-is-top="{{$post->is_top}}"
    >
        <td>{{++$key}}.</td>
        <td>{{$post->title}}</td>
        <td>{{$post->created_at}}</td>
        <td>
            @if ($post->deleted_at !== null)
                <button type="button" class="btn btn-primary js-btn-action restore"></button>
            @else
                <button type="button" class="btn btn-danger js-btn-action delete"></button>
            @endif
        </td>
    </tr>
@endforeach

@foreach ($advisories as $key=>$advisory)
    <tr
        data-id="{{$advisory->id}}"
    >
        {{--<td>{{++$key}}.</td>--}}
        <td title="{{$advisory->title}}">{{$advisory->title}}</td>
        <td title="{{$advisory->name}}">{{$advisory->name}}</td>
        <td title="{{$advisory->address}}">{{$advisory->address}}</td>
        <td title="{{$advisory->email}}">{{$advisory->email}}</td>
        <td title="{{$advisory->phone}}">{{$advisory->phone}}</td>
        <td>
            @if ($advisory->processed == 0)
                <button type="button" class="btn btn-primary btn-do-advised not-advised"></button>
            @else
                <button type="button" class="btn btn-info btn-do-advised advised"></button>
            @endif
        </td>
    </tr>
@endforeach
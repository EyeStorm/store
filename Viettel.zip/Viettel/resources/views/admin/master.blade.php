<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>Viettel Bình Dương - Tổng đài lắp đặt Internet Cáp quang</title>
        <link href="{{asset('images/icons/viettel-icon.png')}}" rel="shortcut icon" type="image/x-icon" title="Favicon">

        <link rel="stylesheet" href="{{ asset('css/w3.css') }}">
        <link rel="stylesheet" href="{{ asset('css/style.css') }}">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
            .w3-bar,h1,button {font-family: "Montserrat", sans-serif}
            .fa-anchor,.fa-coffee {font-size:200px}
        </style>
        @yield('css')

        <script src="{{ asset('vendor/jquery/jquery-2.0.2.min.js') }}"></script>
        <script src="{{ asset('vendor/slider/jssor/jssor.slider.min.js') }}"></script>
        <script src="{{ asset('js/autoload.js') }}"></script>
        @yield('js')
    </head>

    <body>
        {{----}}
        <main class="@yield('main.class')">
            @yield('content')
        </main>
    </body>
</html>

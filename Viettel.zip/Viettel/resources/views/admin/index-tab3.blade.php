
{{----}}
<section id="content3" class='tab-content' >

{{-- Content Left --}}
<div class="content-left">
<div class="dd nestable slider_list">
    <div class="header_title_list">
        Slider
        <button type="button" class="btn btn-primary add-slider">Thêm</button>
    </div>
    <ol class="dd-list">
        @foreach ($sliders as $slider)
            <li class="dd-item dd3-item"
                data-id="{{$slider->id}}"
                data-slider-image="{{$slider->image}}"
                data-slider-content="{{$slider->content}}"
            >
                <div class="dd-handle dd3-handle"></div>
                @if ($slider->deleted_at !== null)
                    <input class="dd3-content deleted" value="{{$slider->title}}" />
                @else
                    <input class="dd3-content " value="{{$slider->title}}" />
                @endif
            </li>
        @endforeach
    </ol>
    <div class="footer_title_list">
        <button type="button" class="btn btn-primary save-slider active">Lưu</button>
        <button type="button" class="btn toggle-delete-slider"></button>
    </div>
</div>
</div>

{{-- Content Right --}}
<div class="content-right">
<div class="btn-group">
    <button type="button" class="btn btn-primary update-slider">Lưu</button>
</div>
<div class="slider-content">
    <textarea  name="slider_content_editor" class="slider_content_editor" id="slider_content_editor"></textarea>
</div>
<div class="slider-image">
    <div class="input-group">
       <span class="input-group-btn">
         <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
           <i class="fa fa-picture-o"></i> Chọn hình
         </a>
       </span>
        <input id="thumbnail" class="form-control" type="text" name="filepath" style="display: none"/>
    </div>
    <img id="holder" style="width: 100%;">
</div>
</div>

{{-- DOM event--}}
<script>
$("label[for='tab3']").click(function(){
    $(".slider_list input.dd3-content").first().trigger("click");
});

$('.slider_list').nestable({
    maxDepth:1,
    onDrop : function(item){
        $(item).find("input").trigger("change");
    }
});

$(document).on("change",".slider_list input.dd3-content", function () {
    $('.slider_list .save-slider').addClass("active");
});

$(document).on("click",".slider_list input.dd3-content", function () {
    // Set data content
    let $content = $(this).parent("li").data("slider-content");
    if ( $content === undefined) {
        $content = "";
    }
    tinymce.get('slider_content_editor').setContent($content);
    let $imgSrc = $(this).parent("li").data("slider-image");
    $imgSrc = defaultImage($imgSrc);
    $("input#thumbnail").val($imgSrc);
    $("img#holder").attr("src", $imgSrc);

    // Change display view
    $(".slider_list input.dd3-content").removeClass("current");
    $(this).addClass("current");

    // Init delete button
    if ( $(this).hasClass("deleted") ) {
        $(".toggle-delete-slider")
            .addClass("btn-primary restore")
            .removeClass("btn-danger delete");
    } else {
        $(".toggle-delete-slider")
            .addClass("btn-danger delete")
            .removeClass("btn-primary restore");
    }
});

$('.slider_list .add-slider').on("click", function(){
    let $li = $("<li class='dd-item dd3-item'>");
    $li.append($("<div class='dd-handle dd3-handle'>Drag</div>"));
    $li.append($("<input class='dd3-content' value='Tiêu đề'/>"));
    $(".slider_list > ol").append($li);
    $('.slider_list .save-slider').addClass("active");
});

$('.slider_list .save-slider').on("click", function(){
    let $sliders = [];
    $(".slider_list input.dd3-content").each(function(index, element){
        let $sliderID = $(element).parent("li").data("id");
        let $slider = {
            title       : $(element).val(),
            priority    : index+1
        };
        if ($sliderID !== undefined) {
            $slider.id = $sliderID;
        }
        $sliders.push($slider);
    });
    $.ajax({
        url: "{{ route("slider.update") }}",
        type:"PUT",
        data : {sliders:$sliders},
        dataType: "JSON",
        success: function($post) {
        }
    });
    $(this).removeClass("active");
});

$('#content3 .update-slider').on("click", function(){
    let $sliders = [];
    let $sliderEl = $(".slider_list input.dd3-content.current");
    let $slider = {
        title       : $sliderEl.val(),
        content     : tinymce.get('slider_content_editor').getContent({format: 'raw'}),
        image       : $("input#thumbnail").val(),
        priority    : $sliderEl.parent("li").index()+1
    };
    let $sliderID = $sliderEl.parent("li").data("slider-id");
    if ($sliderID !== undefined) {
        $slider.id = $sliderID;
    }
    $sliders.push($slider);
    $.ajax({
        url: "{{ route("slider.update") }}",
        type:"PUT",
        data : {sliders:$sliders},
        dataType: "JSON",
        success: function($post) {
        }
    });
});

$('#content3 .toggle-delete-slider').on("click", function(){
    //
    let $sliderEl = $(".slider_list input.dd3-content.current");
    let $sliderID = $sliderEl.parent("li").data("id");
    let $isDelete = $(".toggle-delete-slider").hasClass("delete");
    //
    if ($sliderID === undefined) {
        if ( $isDelete ) {
            $sliderEl.parent("li").remove();
            $(".slider_list input.dd3-content").first().trigger("click");
        }
        return;
    }
    //
    let $element = $(this);
    let $route = "{{ route("slider.delete") }}/" + $sliderID;
    let $type = "DELETE";
    if ( !$isDelete ) {
        $route = "{{ route("slider.restore") }}/" + $sliderID;
        $type = "PUT";
    }
    //
    $.ajax({
        url: $route,
        type: $type,
        success: function($response) {
            $element.toggleClass('delete btn-primary restore btn-danger');
            $sliderEl.toggleClass('deleted');
        }
    });
});


var slider_editor_config = {
    path_absolute : "/",
    selector: "textarea.slider_content_editor",
    relative_urls: false,
    file_browser_callback : function(field_name, url, type, win) {
        var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
        var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

        tinyMCE.activeEditor.windowManager.open({
            file : cmsURL,
            title : 'Filemanager',
            width : x * 0.8,
            height : y * 0.8,
            resizable : "yes",
            close_previous : "no"
        });
    },
    language: "vi_VN"
};
tinymce.init(slider_editor_config);

$('#lfm').filemanager('image', {prefix: ""});
</script>
{{-- Function JS--}}
<script>
</script>

</section>
@component('admin.index-tab-base')

@slot('id')
content4
@endslot

@slot('class')
@endslot

@slot('contentBoth')
@endslot

@slot('contentLeft')
<div class="dd nestable newFeed_list">
    <div class="header_title_list">
        Dánh sách quảng cáo
        <button type="button" class="btn btn-primary btn-add-item-list">Thêm</button>
    </div>
    <ol class="dd-list">
        @foreach ($newfeeds as $item)
            <li class="dd-item dd3-item"
                data-id="{{$item->id}}"
                data-image="{{$item->img_path}}"
                data-links="{{$item->links}}"
            >
                <div class="dd-handle dd3-handle"></div>
                @if ($item->deleted_at !== null)
                    <input class="dd3-content deleted" value="{{$item->title}}" />
                @else
                    <input class="dd3-content " value="{{$item->title}}" />
                @endif
            </li>
        @endforeach
    </ol>
    <div class="footer_title_list">
        <button type="button" class="btn btn-primary de-active btn-update-item-list">Lưu</button>
        <button type="button" class="btn btn-primary toggle-show-item-newfeed delete"></button>
    </div>
</div>
@endslot

@slot('contentRight')
<div class="btn-group">
    <button type="button" class="btn btn-primary update-newFeed">Lưu</button>
</div>
<div>
    Link liên kết : <input class="form-control newFeed-link" />
</div>
<div class="newFeed-image" style="text-align: center;">
    <div class="input-group">
        <span class="input-group-btn">
            <a id="lfm-newFeed" data-input="newFeed-thumbnail" data-preview="newFeed-holder" class="btn btn-primary">
                <i class="fa fa-picture-o"></i>Chọn hình
            </a>
        </span>
        <input id="newFeed-thumbnail" class="form-control" type="text" style="display: none" />
    </div>
    {{--<img id="newFeed-holder" class="lfm-image-view" width="100%" />--}}
    <img id="newFeed-holder" class="lfm-image-view" width="70%" style="width: 70%;border: 1px solid;">
</div>
@endslot

@slot('domEventScript')
<script>
$("label[for='tab4']").click(function(){
    $(".newFeed_list input.dd3-content").first().trigger("click");
});

$('.newFeed_list').nestable({
    maxDepth:1,
    onDrop : function(item){
        $(item).find("input").trigger("change");
    }
});

$(document).on("change",".newFeed_list input.dd3-content", function () {
    $('.newFeed_list .btn-update-item-list').addClass("active");
});

$('.btn-add-item-list').on('click', function(){
    let $li = $("<li class='dd-item dd3-item'>");
    $li.append($("<div class='dd-handle dd3-handle'>Drag</div>"));
    $li.append($("<input class='dd3-content' value='Tiêu đề...'/>"));
    $(this).parents(".nestable").find("ol").append($li);
    $('.btn-update-item-list').addClass("active");
});

$(document).on("click",".newFeed_list input.dd3-content", function () {
    // Set data content
    let $links = $(this).parent("li").data("links");
    let $imgSrc = $(this).parent("li").data("image");
    $imgSrc = defaultImage($imgSrc);
    $("input#newFeed-thumbnail").val($imgSrc);
    $("img#newFeed-holder").attr("src", $imgSrc);
    $(".newFeed-link").val($links);
    // Change display view
    $(".newFeed_list input.dd3-content").removeClass("current");
    $(this).addClass("current");

    // Init delete button
    if ( $(this).hasClass("deleted") ) {
        $(".toggle-show-item-newfeed")
            .addClass("btn-primary restore")
            .removeClass("btn-danger delete");
    } else {
        $(".toggle-show-item-newfeed")
            .addClass("btn-danger delete")
            .removeClass("btn-primary restore");
    }
});

$('.update-newFeed').on("click", function(){
    let $element = $(".newFeed_list input.dd3-content.current");
    let $itemID = $element.parent("li").data("id");
    let $item = {
        title       : $element.val(),
        links       : $(".newFeed-link").val(),
        img_path    : $("input#newFeed-thumbnail").val()
    };
    if ($itemID !== undefined) {
        $item.id = $itemID;
    }
    $.ajax({
        url     : "{{ route("advertisement.save") }}",
        type    : "POST",
        data    : $item,
        dataType: "JSON",
        success: function($post) {}
    });
});

$('.newFeed_list .btn-update-item-list').on("click", function(){
    let $newFeeds = [];
    $(".newFeed_list input.dd3-content").each(function(index, element){
        let $sliderID = $(element).parent("li").data("id");
        let $slider = {
            title       : $(element).val(),
            priority    : index+1
        };
        if ($sliderID !== undefined) {
            $slider.id = $sliderID;
        }
        $newFeeds.push($slider);
    });
    $.ajax({
        url: "{{ route("advertisement.update") }}",
        type:"PUT",
        data : {advertisements:$newFeeds},
        dataType: "JSON",
        success: function($post) {
        }
    });
    $(this).removeClass("active");
});

$('.toggle-show-item-newfeed').on("click", function(){
    //
    let $itemEl = $(".newFeed_list input.dd3-content.current");
    let $itemID = $itemEl.parent("li").data("id");
    let $isDelete = $(this).hasClass("delete");
    //
    if ($itemID === undefined) {
        if ( $isDelete ) {
            $itemEl.parent("li").remove();
            $(".newFeed_list input.dd3-content").first().trigger("click");
        }
        return;
    }
    //
    let $element = $(this);
    let $route = "{{ route("advertisement.delete") }}/" + $itemID;
    let $type = "DELETE";
    if ( !$isDelete ) {
        $route = "{{ route("advertisement.restore") }}/" + $itemID;
        $type = "PUT";
    }
    //
    $.ajax({
        url: $route,
        type: $type,
        success: function($response) {
            $element.toggleClass('delete btn-primary restore btn-danger');
            $itemEl.toggleClass('deleted');
        }
    });
});

$('#lfm-newFeed').filemanager('image', {prefix: ""});
</script>
@endslot

@slot('funcScript')
@endslot

@endcomponent


<ul>
@foreach ($categories as $category)
    @if (count($category['child']) > 0)
        <li class="expand"><a data-route-id="{{ $category['id']}}" data-route="{{ $category['route']}}">{{ $category['name'] }}</a>
        @include('admin.nav', array('categories' => $category['child']))
        </li>
    @else
        <li><a data-route-id="{{ $category['id']}}" data-route="{{ $category['route']}}">{{ $category['name'] }}</a></li>
    @endif
@endforeach
</ul>

@component('admin.index-tab-base')

@slot('id')
content5
@endslot

@slot('class')
@endslot

@slot('contentBoth')
@endslot

@slot('contentLeft')
<div class="dd nestable advisory_list">
    <div class="header_title_list">
        Dánh sách
    </div>
    <ol class="dd-list">
        @foreach ($advisories as $advisory)
            <li class="dd-item"
                data-date='@date($advisory->created_at)'
            >
                @if ($advisory->deleted_at !== null)
                    <div class="dd-handle">@date($advisory->created_at)</div>
                @else
                    <div class="dd-handle">@date($advisory->created_at)</div>
                @endif
            </li>
        @endforeach
    </ol>
    <div class="footer_title_list">
    </div>
</div>
@endslot

@slot('contentRight')
<table class="list-advisory">
    <thead>
    {{--<tr>--}}
        {{--<td colspan="6" class="group_btn">--}}
            {{--<div>--}}
            {{--</div>--}}
        {{--</td>--}}
    {{--</tr>--}}
    <tr class="header_title">
        {{--<th>STT</th>--}}
        <th>Tiêu đề</th>
        <th>Tên</th>
        <th>Địa chỉ</th>
        <th>Mail</th>
        <th>Điện thoại</th>
        <th>Trạng thái</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
@endslot

@slot('domEventScript')
<script>
//$('.advisory_list').nestable({
//    maxDepth:1
//});
$(".advisory_list .dd-handle").on("click", function () {
    let $itemCondition = $(this).parent("li.dd-item").data("date");
    $.ajax({
        url: "{{ route("advisory.date.list") }}/" + $itemCondition,
        type: "GET",
        success: function($response) {
            $(".list-advisory tbody").html($response);
        }
    });
    $(".advisory_list .dd-handle").removeClass("current");
    $(this).addClass("current");
}).first().click();

$(document).on('click','button.btn-do-advised', function(){
    let $element = $(this);
    let $itemId = $element.parents("tr").data("id");
    let $type = "PUT";

    let $advisory = {
        processed    : 1
    };
    if ( $(this).hasClass('advised') ) {
        $advisory.processed = 0;
    }

    $.ajax({
        url: "{{ route("advisory.do.advised") }}/" + $itemId,
        type: $type,
        data: $advisory,
        success: function($response) {
            $element.toggleClass('not-advised btn-primary advised btn-info');
        }
    });
});

</script>
@endslot

@slot('funcScript')
@endslot

@endcomponent
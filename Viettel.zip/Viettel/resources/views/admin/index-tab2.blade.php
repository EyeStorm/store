@component('admin.index-tab-base')

@slot('id')
    content2
@endslot

@slot('class')
    fill-both
@endslot

@slot('contentBoth')
<table class="info-post">
    <tr>
        <th>Menu :</th>
        <td>
            <select class="menu-child" name="menuItem">
                <option></option>
                @foreach ($menus as $menu)
                    <option value="{{$menu->id}}">{{ $menu->name }}</option>
                @endforeach
            </select>
            <label class="clear-default"><input type="checkbox" class="is_top"/>Hiện ở menu</label>
        </td>
    </tr>
    {{--
    <tr>
        <th>Phân loại :</th>
        <td>
            <select class="tag-child" name="tagItem">
                <option></option>
                @foreach ($tags as $tag)
                    <option value="{{$tag->id}}">{{ $tag->name }}</option>
                @endforeach
            </select>
        </td>
    </tr>
    --}}
    <tr>
        <th>Tiêu đề :</th>
        <td>
            <input class="post_title" />
            <input class="post_id" type="hidden" />
        </td>
    </tr>
    <tr>
        <th>Nội dung :</th>
        <td class="group-buton">
            <div>
                <button type="button" class="btn btn-primary new-post">Tạo mới</button>
                <button type="button" class="btn btn-primary save-post">Lưu</button>
                {{--<button type="button" class="btn btn-danger delete"></button>--}}
            </div>
        </td>
    </tr>
</table>
<textarea  name="post-detail" class="post-detail" id="post-detail" style="height: 100%"></textarea>
@endslot

@slot('contentLeft')@endslot

@slot('contentRight')@endslot

@slot('domEventScript')
<script>
$(".menu-child").select2({
    placeholder: "Chọn menu...",
    allowClear: true
});

$("button.save-post").on("click", function () {
    let $contentPost = tinymce.get("post-detail").getContent();
    let $shortContentPost = tinymce.get("post-detail").getContent({ format: 'text' });
    let $iconPath = $($contentPost).find("img").first().attr("src");
    let $isTop = $("table.info-post .is_top").prop("checked") ? 1 : 0;

    let $post = {
        id         : $("table.info-post .post_id").val(),
        title      : $("table.info-post .post_title").val(),
        is_top     : $isTop,
        content    : $contentPost,
        short_content : $shortContentPost,
        icon_path  : defaultImage($iconPath),
        category_id: $(".menu-child").val()
    };
    $.ajax({
        url: "{{ route("post.save") }}",
        type:"POST",
        data : $post,
        dataType: "JSON",
        success: function($post) {
        }
    });
});


let editor_config = {
    path_absolute : "/",
    selector: "textarea.post-detail",
    plugins: [
        "image imagetools",
        "advlist autolink lists link  charmap print preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime media nonbreaking save table contextmenu directionality",
        "emoticons template paste textcolor colorpicker textpattern"
    ],
    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    relative_urls: false,
    file_browser_callback : function(field_name, url, type, win) {
        let x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
        let y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

        let cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
        if (type === 'image') {
            cmsURL = cmsURL + "&type=Images";
        } else {
            cmsURL = cmsURL + "&type=Files";
        }

        tinyMCE.activeEditor.windowManager.open({
            file : cmsURL,
            title : 'Filemanager',
            width : x * 0.8,
            height : y * 0.8,
            resizable : "yes",
            close_previous : "no"
        });
    },
    language: "vi_VN"
};
tinymce.init(editor_config);
</script>
@endslot

@slot('funcScript')
<script>
</script>
@endslot

@endcomponent
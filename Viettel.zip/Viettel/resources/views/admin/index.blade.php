@extends('admin.master')

@section('css')
    <link href="{{asset('vendor/select2/css/select2.min.css')}}" rel="stylesheet" />
    <!-- Styles -->
    <link href="{{asset('css/admin.css')}}" rel="stylesheet" type="text/css"/>
    <style>
    </style>
@endsection

@section('js')
{{-- Drag&Drop--}}
<script src="{{asset('vendor/drag-drop/nestable/jquery.nestable.js')}}"></script>
{{-- Select2--}}
<script src="{{asset('vendor/select2/js/select2.min.js')}}"></script>
{{-- Tinymce --}}
<script src="{{asset('vendor/tinymce/tinymce.min.js')}}"></script>
{{-- Filemanager --}}
<script src="{{asset('vendor/laravel-filemanager/js/lfm.js')}}"></script>
{{----}}
@endsection

@section('main.class') tab-design @endsection
@section('content')


    <input id="tab1" type="radio" name="tabs" checked />
    <label for="tab1">Bài viết</label>
    <input id="tab2" type="radio" name="tabs" />
    <label for="tab2">Chỉnh sửa bài viết</label>
    <input id="tab3" type="radio" name="tabs" />
    <label for="tab3">Slider</label>
    <input id="tab4" type="radio" name="tabs" />
    <label for="tab4">Quảng cáo</label>
    <input id="tab5" type="radio" name="tabs" />
    <label for="tab5">Tư vấn</label>

    {{----}}
    @include('admin.index-tab1')
    @include('admin.index-tab2')
    @include('admin.index-tab3')
    @include('admin.index-tab4')
    @include('admin.index-tab5')

@endsection



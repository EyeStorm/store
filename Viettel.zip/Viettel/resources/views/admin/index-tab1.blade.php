@component('admin.index-tab-base')
{{-- Place id--}}
@slot('id') content1 @endslot
{{-- Place more class--}}
@slot('class')
@endslot

@slot('contentBoth')
@endslot

{{----}}
@slot('contentLeft')
<div class="dd nestable js-list-post" id="nestable">
    <div class="header_title_list">
        Danh sách menu
        <button type="button" class="btn btn-primary js-btn-add-item-list">Thêm</button>
    </div>
    @include('admin.nes-nav', array('menus' => $menus))
    <div class="footer_title_list">
        <button type="button" class="btn btn-primary de-active js-btn-update-item-list">Lưu</button>
        <button type="button" class="btn btn-primary toggle-show-item-list delete"></button>
        <button type="button" class="btn btn-danger toggle-show-item-list force-delete"></button>
    </div>
</div>
@endslot

{{----}}
@slot('contentRight')
<table class="list_post">
    <thead>
    <tr>
        <td colspan="4" class="group_btn">
            <div>
                <button type="button" class="btn btn-primary js-edit-post">Chỉnh sửa</button>
                <button type="button" class="btn btn-primary new-post">Bài mới</button>
            </div>
        </td>
    </tr>
    <tr class="header_title">
        <th>STT</th>
        <th>Tiêu đề</th>
        <th>Ngày tạo</th>
        <th>Trạng thái</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
@endslot

{{-- DOM event--}}
@slot('domEventScript')
<script>
//
$('#content1 .js-btn-add-item-list').on('click', function(){
    let $li = $("<li class='dd-item dd3-item'>");
    $li.append($("<div class='dd-handle dd3-handle'></div>"));
    $li.append($("<input class='dd3-content' value='Tiêu đề...'/>"));
    $(this).parents("div.nestable").find("ol").append($li);
    $('.js-btn-update-item-list').addClass("active");
});
//
$('.toggle-show-item-list').on("click", function(){
    let $element = $(this);
    //
    let $itemEl = $element.parents("div.nestable").find("input.dd3-content.current");
    let $itemID = $itemEl.parent("li").data("id");
    let $isDelete = $(this).hasClass("delete");
    let $isForceDelete = $(this).hasClass("force-delete");
    //
    if ($itemID === undefined) {
        if ( $isDelete ) {
            $itemEl.parent("li").remove();
            $element.parents("div.nestable").find("input.dd3-content").first().trigger("click");
        }
        return;
    }
    //
    let $route = "{{ route("menus.delete") }}/" + $itemID;
    let $type = "DELETE";
    if ( !$isDelete ) {
        $route = "{{ route("menus.restore") }}/" + $itemID;
        $type = "PUT";
    }
    let $data = Object.create(null);
    if ($isForceDelete) {
        $data.force = true;
    }
    //
    $.ajax({
        url: $route,
        type: $type,
        data: $data,
        dataType: "JSON",
        success: function($response) {
            $element.toggleClass('delete btn-primary restore btn-danger');
            $itemEl.toggleClass('deleted');
        }
    });
});
//
$('.js-btn-update-item-list').on("click", function(){
    let $menus = [];
    $(".js-list-post input.dd3-content").each(function(index, element){

        let $parentMenu = $($(this).parents("li")[1]);
        let $parentID = $parentMenu.data("id");
        if ( $parentID === undefined ) {
            $parentID = 0;
        }
        let $menuID = $(element).parent("li").data("id");
        let $menu = {
            name        : $(this).val(),
            parent_id   : $parentID,
            priority    : $(this).parent("li").index()+1
        };
        if ($menuID !== undefined) {
            $menu.id = $menuID;
        }
        $menus.push($menu);
    });

    $.ajax({
        url: "{{ route("menus.update") }}",
        type:"PUT",
        data : {menus:$menus},
        dataType: "JSON",
        success: function($response) {}
    });
    $(this).removeClass("active");
});
//
$('.js-list-post').nestable({
    maxDepth:1,
    onDrop : function(menuItem){
        $('.js-btn-update-item-list').addClass("active");
    }
});
let contentMenu = ".js-list-post input.dd3-content";
$(document).on("change", contentMenu, function(){
    $('.js-btn-update-item-list').addClass("active");
});
$(document).on("click", contentMenu, function () {
    let $routeId = $(this).parent("li.dd3-item").data("id");
    $.ajax({
        url: "{{ route("posts.route.list") }}/" + $routeId,
        type: "GET",
        success: function($response) {
            $(".list_post tbody").html($response);
        }
    });
    $(contentMenu).removeClass("current");
    $(this).addClass("current");
    // Init delete button
    if ( $(this).hasClass("deleted") ) {
        $(".toggle-show-item-list")
            .addClass("btn-primary restore")
            .removeClass("btn-danger delete");
    } else if(!$(this).hasClass("force-delete")) {
        $(".toggle-show-item-list")
            .addClass("btn-danger delete")
            .removeClass("btn-primary restore");
    }
}).first().click();

$(document).on("click","table.list_post tbody td", function () {
    $("table.list_post tbody tr").removeClass("current");
    $(this).parents("table.list_post tbody tr").addClass("current");
});

$(document).on('click','button.js-btn-action', function(){
    let $element = $(this);
    let $postId = $element.parents("tr").data("post-id");
    let $route = "{{ route("post.delete") }}/" + $postId;
    let $type = "DELETE";
    if ( $(this).hasClass('restore') ) {
        $route = "{{ route("post.restore") }}/" + $postId;
        $type = "PUT";
    }
    $.ajax({
        url: $route,
        type: $type,
        success: function($response) {
            $element.toggleClass('delete btn-primary restore btn-danger');
        }
    });
});

$("button.js-edit-post").on("click", function () {
    let $postCurrentEl = $("table.list_post tbody tr.current");
    if ( $postCurrentEl.length === 0 ) {
        return;
    }
    let $postId = $postCurrentEl.data("post-id");
    $.ajax({
        url         : "{{ route("post.get") }}/" + $postId,
        type        : "GET",
        dataType    : "JSON",
        success     : function($post) {

            let $routeId = $("input.dd3-content.current").parent("li.dd3-item").data("id");
            $("select[name=menuItem]").val($routeId).trigger('change');

            $("table.info-post .post_id").val($post.id);
            $("table.info-post .post_title").val($post.title);
            let $isTop = $post.is_top == 1 ? true : false;
            $("table.info-post .is_top").prop("checked", $isTop);
            tinymce.get("post-detail").setContent($post.content);
            $("label[for='tab2']").trigger('click');
        }
    });
});
</script>

{{-- In orther tab --}}
<script>
$("button.new-post").on("click", function () {
    let $routeId = $("input.dd3-content.current").parent("li.dd3-item").data("route-id");
    $("select[name=menuItem]").val($routeId).trigger('change');
    $("table.info-post .post_title").val('');
    $("table.info-post .is_top").prop("checked", false);
    tinymce.get("post-detail").setContent('');
    $("label[for='tab2']").trigger('click');
});
//
$("label[for='tab2']").click(function($event){
    if( $event.originalEvent !== undefined && !$("#tab2").is(":checked") ) {
        $("select[name=menuItem]").val('').trigger('change');
        $("table.info-post .post_title").val('');
        $("table.info-post .is_top").prop("checked", false);
        tinymce.get("post-detail").setContent('');
    }
});
</script>
@endslot

{{-- Function JS--}}
@slot('funcScript')
<script>
</script>
@endslot

@endcomponent

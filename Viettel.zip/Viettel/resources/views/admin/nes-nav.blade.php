
<ol class="dd-list">
@foreach ($menus as $menu)
@if ($menu->show_category_child = 0)
    <li class="dd-item dd3-item" data-id="{{ $menu->id}}">
        <div class="dd-handle dd3-handle"></div>
        @if ($menu->deleted_at !== null)
            <input class="dd3-content deleted" value="{{$menu->name}}" />
        @else
            <input class="dd3-content " value="{{$menu->name}}" />
        @endif
        @include('admin.nes-nav', array('categories' => $menu->PostsForHeader))
    </li>
@else
    <li class="dd-item dd3-item" data-id="{{ $menu->id}}" >
        <div class="dd-handle dd3-handle"></div>
        @if ($menu->deleted_at !== null)
            <input class="dd3-content deleted" value="{{$menu->name}}" />
        @else
            <input class="dd3-content " value="{{$menu->name}}" />
        @endif
    </li>
@endif
@endforeach
</ol>
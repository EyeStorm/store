<!-- Slideshow -->
<div id="slider1_container" class="w3-container banner-2">
    <div data-u="slides" class="slides">
        @foreach ($arySlider as $objSlider)
            <div class="w3-display-container">
                <img data-u="image" src="{{ asset($objSlider->image) }}" style="width:100%">
                <div data-u="caption" data-t="0" class="slides_mota" >
                    <h4>{{ $objSlider->title }}</h4>
                    <p>{!! $objSlider->content !!}</p>
                </div>
            </div>
        @endforeach
    </div>
    <!-- Slideshow next/previous buttons -->
    <div data-u="navigator" class="w3-container w3-padding w3-xlarge banner-nav" data-scale="0.5" data-scale-bottom="0.75">
        <div data-u="prototype" class="i">
            <span class="b w3-tag demodots w3-border w3-hover-white"></span>
        </div>
    </div>
</div>

<script>
    jQuery(document).ready(function ($) {
        var jssor_1_SlideoTransitions = [[{b:0,d:600,y:-190,e:{y:27}}]];
        var options = {
            $FillMode: 2,
            $AutoPlay: 1,
            $Idle: 4000,
            $PauseOnHover: 1,
            $ArrowKeyNavigation: 1,
            $SlideEasing: $Jease$.$OutQuint,
            $SlideDuration: 1200,
            $MinDragOffsetToSlide: 20,
            $SlideSpacing: 0,
            $Cols: 1,
            $Align: 0,
            $UISearchMode: 1,
            $PlayOrientation: 1,
            $DragOrientation: 1,
            $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$,
                $ChanceToShow: 2,
                $Steps: 1,
                $Rows: 1,
                $SpacingX: 8,
                $SpacingY: 8,
                $Orientation: 1
            },
            $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$,
                $ChanceToShow: 2,
                $Steps: 1
            },
            $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: jssor_1_SlideoTransitions,
                $Breaks: [
                    [{d:2000,b:1000}]
                ]
            }
        };
        var jssor_slider1 = new $JssorSlider$('slider1_container', options);
        /*#region responsive code begin*/
        //you can remove responsive code if you don't want the slider scales while window resizing
        function ScaleSlider() {
            var bodyWidth = document.body.clientWidth;
            if (bodyWidth)
                jssor_slider1.$ScaleWidth(Math.min(bodyWidth, 1920));
            else
                $Jssor$.$Delay(ScaleSlider, 30);
        }

        ScaleSlider();
        $(window).bind("load", ScaleSlider);
        $(window).bind("resize", ScaleSlider);
        $(window).bind("orientationchange", ScaleSlider);
        /*#endregion responsive code end*/


        $('#btn-bar-button').click(function(e) {
            $('#mySidebar').toggle( "slide" );
        });
    });
</script>
<header>
    <div class="banner">
        <a href='{{ route("home.index") }}' >
            <img class="banner-logo" src="images/header/logo.png" />
        </a>
        <i class="fa fa-bars menu-btn" aria-hidden="true"></i>
    </div>

    <div class="div-menu">
        <a href='{{ route("home.index") }}' class="logo-fix">
            <img src="images/icons/viettel-icon.png" class="logo-fix-icon">
        </a>
        <ul>
            <li class="w3-bar-item w3-button w3-padding-large w3-hover-white"><a href='{{ route("news.index") }}'><span>Tin tức</span></a></li>
            @foreach ($aryCategory as $objCategory)
                <li class="w3-bar-item w3-button w3-padding-large w3-hover-white has-sub"><a href='javascript:void(0);'><span>{{ $objCategory->name }}</span></a>
                    <ul>
                        @foreach ($objCategory->PostsForHeader as $post)
                            <li><a href='{{ route("home.detail", ["id" => $post->id]) }}'>{{ $post->title }}</a></li>
                        @endforeach
                    </ul>
                </li>
            @endforeach
            <li class="w3-bar-item w3-button w3-padding-large w3-hover-white"><a href='{{ route("home.contact") }}'><span>Liên hệ</span></a></li>
        </ul>
    </div>

    <nav>
        <ul>
            <li><a href="{{ route("news.index") }}">Tin tức</a></li>

            @foreach ($aryCategory as $objCategory)
            <li class="expand"><a href='javascript:void(0);'><span>{{ $objCategory->name }}</span></a>
            <ul>
            @foreach ($objCategory->PostsForHeader as $post)
            <li><a href='{{ route("home.detail", ["id" => $post->id]) }}'>{{ $post->title }}</a></li>
            @endforeach
            </ul>
            </li>
            @endforeach

            <li><a href="{{ route("home.contact") }}">Liên hệ</a></li>
        </ul>
    </nav>

    <script>
        $(document).on('scroll', function(){
            // 
            if ($(".banner").is(":onscreen")) {
                $(".div-menu").removeClass("div-menu-fixed");
            } else {
                $(".div-menu").addClass("div-menu-fixed");
            }
        });

        //
        $('.div-menu > ul > li')
        .click(function (e) {
            let parent = $(this);
            $('.nav-overlay').show();
            $('.w3-top > div').addClass('show-menu');
            $('.div-menu > ul > li > ul > li').hide('fast', function(){
                let lis = parent.children('ul').children('li');
                $(lis).each(function(index) {
                    let li = $(this);
                    setTimeout(function() {
                        li.slideDown(50);
                    }, 50 * index);
                });
            });
        })
        .mouseleave(function (e) {
                $('.div-menu > ul > li > ul > li').hide();
                $('.nav-overlay').hide();
            }
        );
    </script>
{{--    @include('base.slider', ['arySlider' => $arySlider])--}}
</header>
<footer class="w3-container w3-padding-32 w3-margin-top viettel-bar-color">
    <div>
        <a href="#" class="w3-button w3-black w3-padding-large"><i class="fa fa-arrow-up w3-margin-right"></i>Lên đầu trang</a>
        <h3>TỔNG ĐÀI INTERNET CÁP QUANG - MẠNG VIETTEL BÌNH DƯƠNG</h3>
        <h4>Điện thoại:
        <span class="phone">
            <a href="tel:01627449999" class="none-decoration phone">01627449999</a>
            -
            <a href="tel:0979125678" class="none-decoration phone">0979125678</a>
        </span>
        </h4>
        <h4>Khu vực hỗ trợ: Thủ Dầu Một, Thuận An, Dĩ An, Bến Cát, Tân Uyên </h4>
    </div>
</footer>

<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Viettel Bình Dương - Tổng đài lắp đặt Internet Cáp quang</title>
        <link href="{{asset('images/icons/viettel-icon.png')}}" rel="shortcut icon" type="image/x-icon" title="Favicon">

        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
{{--        <link rel="stylesheet" href="{{ asset('css/fonts.css') }}">--}}
        <link rel="stylesheet" href="{{ asset('css/w3.css') }}">
        <link rel="stylesheet" href="{{ asset('css/style.css') }}">
        <link rel="stylesheet" href="{{ asset('css/app.css') }}">
        <style>
        </style>
        @yield('css')

        <script src="{{ asset('vendor/jquery/jquery-2.0.2.min.js') }}"></script>
        <script src="{{ asset('vendor/slider/jssor/jssor.slider.min.js') }}"></script>
        <script src="{{ asset('js/autoload.js') }}"></script>
        <script>
        </script>
        @yield('js')
    </head>

    <body>
        {{----}}
        @include('base.header', ['aryCategory' => $aryCategory])
        @include('base.slider', ['arySlider' => $arySlider])

        {{----}}
        <main class=@yield('main.class')>
            @yield('content')
        </main>

        {{----}}
        @include('base.footer')

    </body>
</html>

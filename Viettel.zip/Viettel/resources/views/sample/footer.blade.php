<footer>
    <div class="ref-link">
        <a href="http://mangviettelbinhduong.com/">viettel binh duong</a>
        <a href="http://mangviettelbinhduong.com/">mang viettel binh duong</a>
        <a href="http://mangviettelbinhduong.com/cap-quang-viettel-binh-duong-khuyen-mai-thang-82016/bv38/">cap quang viettel binh duong</a>
        <a href="http://viettelhochiminh.vn/">lắp mạng internet viettel</a>
        <a href="http://mangviettelbinhduong.com/">cáp quang viettel</a>
    </div>

    <div class="info">
        <div class="left">
            <p class="title-name">TỔNG ĐÀI INTERNET CÁP QUANG - MẠNG VIETTEL BÌNH DƯƠNG</p>
            <p class="phone">
                <span class="title-phone">Điện thoại:</span>
                <span class="number-phone">096 552 4224 - 0961 264 666</span>
            </p>
            <p class="title-address">Khu vực hỗ trợ: Thủ Dầu Một, Thuận An, Dĩ An, Bến Cát, Tân Uyên</p>
        </div>
        <div class="right"></div>
    </div>
</footer>
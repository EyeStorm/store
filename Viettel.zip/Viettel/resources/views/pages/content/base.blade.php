@extends('base.master')

@section('css')
@endsection

@section('js')
@endsection

@section('content')
<div class="w3-content">
    <!-- Grid -->
    <div class="w3-row">

        <!-- Home -->
        <div class="w3-col l8 s12">
            @Using($serviceInfo)
            <!-- Service information -->
            {{ $serviceInfo }}
            <hr>
            @endUsing

            @Using($news)
            <!-- News -->
            {{ $news }}
            <hr>
            @endUsing
            <!-- END HOME -->
        </div>

        <!-- Introduction menu -->
        <div class="w3-col l4">
            <!-- About Card and Subscribe -->
            @Using($about)
                {{ $about }}
            <hr>
            @endUsing
            <!-- New services -->
            @isset($newServices)
            @Using($newServices)
                {{ $newServices }}
            <hr>
            @endUsing
            @endisset
            <!-- Advertise -->
            @Using($advertise)
                {{ $advertise }}
            <hr>
            @endUsing
        </div>
    </div>
</div>
@endsection
@extends('base.master')

{{----}}
@section('css')
    <link rel="stylesheet" href="{{ asset('css/w3.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
        .w3-bar,h1,button {font-family: "Montserrat", sans-serif}
        .fa-anchor,.fa-coffee {font-size:200px}
    </style>
@endsection

{{----}}
@section('js')
    <script src="{{ url('vendor/jquery/jquery-1.9.1.min.js') }}"></script>
    <script src="{{ asset('vendor/slider/jssor/jssor.slider.min.js') }}"></script>
    <script src="{{ asset('vendor/common/common.js') }}"></script>
@endsection

{{----}}
@section('content')

    <!-- w3-content defines a container for fixed size centered content,
and is wrapped around the whole page content, except for the footer in this example -->
<div class="w3-content">
<!-- Grid -->
<div class="w3-row">

<!-- News -->
<div class="w3-col l8 s12">
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container bottom-margin-none">
            <h4>Tin tức</h4>
        </div>
        @for ($i = 0; $i < count($aryNews); $i++)
            <div class="w3-row-padding">
                <div class="w3-quarter w3-center w3-padding-16">
                    <a href='{{route("news.detail", ["id" => $aryNews[$i]->id])}}'>
                        <img src="{{ asset($aryNews[$i]->icon_path) }}" alt="{{$aryNews[$i]->title}}" style="width:100%" class="w3-hover-opacity">
                    </a>
                </div>
                <div class="w3-threequarter">
                    <a class="none-decoration" href='{{route("news.detail", ["id" => $aryNews[$i]->id])}}'><h4>{{$aryNews[$i]->title}}</h4></a>
                    <p class="w3-text-grey">{{$aryNews[$i]->content}}</p>
                    <p><i>Ngày đăng: {{ date_format($aryNews[$i]->created_at,"d-m-Y")}}</i></p>
                </div>
            </div>
            <hr/>
        @endfor
        <div class="w3-center">
            <!-- Pagination -->
            <div class="w3-center w3-padding-32">
                <div class="w3-bar">
                    <a href="{{ $aryNews->url(1) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryNews->currentPage() == 1) ? ' disabled' : '' }}">«</a>
                    @for ($i = 1; $i <= $aryNews->lastPage(); $i++)
                        <?php
                        $half_total_links = floor(7 / 2);
                        $from = $aryNews->currentPage() - $half_total_links;
                        $to = $aryNews->currentPage() + $half_total_links;
                        if ($aryNews->currentPage() < $half_total_links) {
                           $to += $half_total_links - $aryNews->currentPage();
                        }
                        if ($aryNews->lastPage() - $aryNews->currentPage() < $half_total_links) {
                            $from -= $half_total_links - ($aryNews->lastPage() - $aryNews->currentPage()) - 1;
                        }
                        ?>
                        @if ($from < $i && $i < $to)
                            <a href="{{ $aryNews->url($i) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryNews->currentPage() == $i)? ' w3-theme' : '' }}">{{ $i }}</a>
                        @endif
                    @endfor
                    <a href="{{ $aryNews->url($aryNews->lastPage()) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryNews->currentPage() == $aryNews->lastPage()) ? ' disabled' : '' }}">»</a>
                </div>
            </div>
        </div>
    </div>
<!-- END NEWS -->
</div>

<!-- Introduction Menu -->
<div class="w3-col l4">
    <!-- New services -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Dự án mới</h4>
        </div>
        <div class="padding-15">
            <div class="w3-white">
                <ul class="w3-ul w3-hoverable w3-white">
                    @foreach ($aryServicesTop as $objServices)
                    <a class="none-decoration" href="{{ route('home.detail', ['id' => $objServices->id]) }}">
                        <li class="w3-padding-16">
                            <img src="{{ asset($objServices->icon_path) }}" alt="{{$objServices->title}}" class="w3-left w3-margin-right" style="width:50px">
                            <span class="w3-large">{{$objServices->title}}</span>
                            <br>
                            <span class="w3-text-grey">{!!substr($objServices->content, 0, 100) . '…'   !!} </span>
                        </li>
                    </a>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
    <hr>
 
    <!-- Advertise -->
    <div>
        <div class="w3-container w3-padding viettel-bar-color margin-container">
            <h4>Quảng cáo</h4>
            @foreach ($aryAdvertisement as $objAdvertisement)
                <a href="{{ route('home.detail', ['id' => $objAdvertisement->post_id]) }}">
                    <img class="w3-image img-advertise" src="{{ asset($objAdvertisement->img_path) }}">
                </a>
            @endforeach
        </div>
    </div>
<!-- END Introduction Menu -->
</div>

<!-- END GRID -->
</div><br>

<!-- END w3-content -->
</div>

@endsection

@component('pages.content.base', [
                'aryServices' => $aryServices
            ])

@slot('serviceInfo')
<!-- Service information -->
<div>
    <div class="w3-container w3-padding viettel-bar-color margin-container">
        <h4>Thông tin dịch vụ</h4>
    </div>
    <!-- Services Grid-->
    @for ($i = 0; $i < count($aryServices); $i++)
        @if ($i%3 == 0)
            <div class="w3-row-padding">
                @endif
                <div class="w3-third w3-container w3-margin-bottom">
                    <a href='{{route("home.detail", ["id" => $aryServices[$i]->id])}}'>
                        <img src="{{ asset($aryServices[$i]->icon_path) }}" alt="{{$aryServices[$i]->title}}" style="width:100%" class="w3-hover-opacity">
                    </a>
                    <div class="w3-container w3-white">
                        <p><b>{{ $aryServices[$i]->title }}</b></p>
                        <p>{!! $aryServices[$i]->content !!}</p>
                        <div class="w3-row">
                            <div class="w3-col m8 s12">
                                <p><a class="w3-button w3-padding-large w3-white w3-border" href='{{route("home.detail", ["id" => $aryServices[$i]->id])}}'><b>READ MORE &raquo;</b></a></p>
                            </div>
                        </div>
                    </div>
                </div>
                @if ($i%3 == 2 || $i == count($aryServices) - 1)
            </div>
        @endif
    @endfor
    <div class="w3-center">
        <!-- Pagination -->
        <div class="w3-center w3-padding-32">
            <div class="w3-bar">
                <a href="{{ $aryServices->url(1) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryServices->currentPage() == 1) ? ' disabled' : '' }}">«</a>
                @for ($i = 1; $i <= $aryServices->lastPage(); $i++)
                    <?php
                    $half_total_links = floor(7 / 2);
                    $from = $aryServices->currentPage() - $half_total_links;
                    $to = $aryServices->currentPage() + $half_total_links;
                    if ($aryServices->currentPage() < $half_total_links) {
                        $to += $half_total_links - $aryServices->currentPage();
                    }
                    if ($aryServices->lastPage() - $aryServices->currentPage() < $half_total_links) {
                        $from -= $half_total_links - ($aryServices->lastPage() - $aryServices->currentPage()) - 1;
                    }
                    ?>
                    @if ($from < $i && $i < $to)
                        <a href="{{ $aryServices->url($i) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryServices->currentPage() == $i)? ' w3-theme' : '' }}">{{ $i }}</a>
                    @endif
                @endfor
                <a href="{{ $aryServices->url($aryServices->lastPage()) }}" class="w3-bar-item w3-button w3-hover-theme {{ ($aryServices->currentPage() == $aryServices->lastPage()) ? ' disabled' : '' }}">»</a>
            </div>
        </div>
    </div>
</div>
@endslot

@slot('news')
<!-- News -->
<div>
    <div class="w3-container w3-padding viettel-bar-color margin-container bottom-margin-none">
        <h4>Tin tức</h4>
    </div>
    <div class="w3-row-padding">
        <div class="w3-quarter w3-center w3-padding-16">
            @if (count($aryNewsTop) > 0)
                <a class="none-decoration" href="{{ route('news.detail', ['id' => $aryNewsTop[0]->id]) }}">
                    <img src="{{ asset($aryNewsTop[0]->icon_path) }}" alt="Norway" style="width:100%" class="w3-hover-opacity">
                </a>
            @endif
        </div>
        <div class="w3-quarter">
            @if (count($aryNewsTop) > 0)
                <a class="none-decoration" href="{{ route('news.detail', ['id' => $aryNewsTop[0]->id]) }}"><h4>{{$aryNewsTop[0]->title}}</h4></a>
                <p class="w3-text-grey">{{$aryNewsTop[0]->content}}</p>
            @endif
        </div>
        <div class="w3-half">
            <div class="w3-white">
                <ul class="w3-ul w3-hoverable w3-white">
                    @for ($i = 1; $i < count($aryNewsTop); $i++)
                        <a class="none-decoration" href="{{ route('news.detail', ['id' => $aryNewsTop[$i]->id]) }}">
                            <li class="w3-padding-16">
                                <img src="{{ asset($aryNewsTop[$i]->icon_path) }}" alt="{{ $aryNewsTop[$i]->title }}" class="w3-left w3-margin-right" style="width:50px">
                                <span class="w3-large">{{ $aryNewsTop[$i]->title }}</span>
                                <br>
                                <span class="w3-text-grey">{{ substr($aryNewsTop[$i]->content, 0, 100) . '…' }}</span>
                            </li>
                        </a>
                    @endfor
                </ul>
            </div>
        </div>
    </div>
</div>
@endslot

@slot('about')
<!-- About Card and Subscribe -->
<div>
    <div class="w3-container w3-padding viettel-bar-color margin-container">
        <h4>Liên hệ</h4>
    </div>
    <div class="padding-15">
        <p><i class="fa fa-map-marker fa-fw w3-xxlarge w3-margin-right"></i>Thủ Dầu Một, Thuận An, Dĩ An, Bến Cát, Tân Uyên</p>
        <div class="div-inline-block"><i class="fa fa-phone fa-fw w3-xxlarge w3-margin-right"></i>
            <div>
                <p>Thủ Dầu Một: 0961 264 666</p>
                <p>Thuận An: 0961 189 589</p>
                <p>Tân Uyên: 0967 239 939</p>
                <p>Bến Cát: 0978 953 336</p>
                <p>Dĩ An:  0961 264 666</p>
            </div>
        </div>
        <p><i class="fa fa-envelope fa-fw w3-xxlarge w3-margin-right"> </i> mangviettelbinhduong@gmail.com</p>
        <br>
        @include('component.form-regist.advisory')
    </div>
</div>
@endslot

@slot('advertise')
<!-- Advertise -->
<div>
    <div class="w3-container w3-padding viettel-bar-color margin-container">
        <h4>Quảng cáo</h4>
        @foreach ($aryAdvertisement as $objAdvertisement)
            <a href="{{ route('home.detail', ['id' => $objAdvertisement->post_id]) }}">
                <img class="w3-image img-advertise" src="{{ asset($objAdvertisement->img_path) }}">
            </a>
        @endforeach
    </div>
</div>
@endslot

@endcomponent
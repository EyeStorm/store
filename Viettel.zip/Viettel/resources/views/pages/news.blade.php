@component('base.content-base', [
                'aryServices' => $aryServices
            ])

@slot('newServices')
<!-- New services -->
<div>
    <div class="w3-container w3-padding viettel-bar-color margin-container">
        <h4>Dự án mới</h4>
    </div>
    <div class="padding-15">
        <div class="w3-white">
            <ul class="w3-ul w3-hoverable w3-white">
                @foreach ($aryServicesTop as $objServices)
                    <a class="none-decoration" href="{{ route('home.detail', ['id' => $objServices->id]) }}">
                        <li class="w3-padding-16">
                            <img src="{{ asset($objServices->icon_path) }}" alt="{{$objServices->title}}" class="w3-left w3-margin-right" style="width:50px">
                            <span class="w3-large">{{$objServices->title}}</span>
                            <br>
                            <span class="w3-text-grey">{!!substr($objServices->content, 0, 100) . '…'   !!} </span>
                        </li>
                    </a>
                @endforeach
            </ul>
        </div>
    </div>
</div>
@endslot

@slot('advertise')
<!-- Advertise -->
<div>
    <div class="w3-container w3-padding viettel-bar-color margin-container">
        <h4>Quảng cáo</h4>
        @foreach ($aryAdvertisement as $objAdvertisement)
            <a href="{{ route('home.detail', ['id' => $objAdvertisement->post_id]) }}">
                <img class="w3-image img-advertise" src="{{ asset($objAdvertisement->img_path) }}">
            </a>
        @endforeach
    </div>
</div>
@endslot

@endcomponent
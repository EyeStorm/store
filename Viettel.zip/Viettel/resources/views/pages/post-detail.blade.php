@component('base.content-base', [
                'aryServices' => $aryServices
            ])

<!-- Advertise -->
@slot('advertise')
<div>
    <div class="w3-container w3-padding viettel-bar-color margin-container">
        <h4>Quảng cáo</h4>
        @foreach ($aryAdvertisement as $objAdvertisement)
            <a href="{{ route('home.detail', ['id' => $objAdvertisement->post_id]) }}">
                <img class="w3-image img-advertise" src="{{ asset($objAdvertisement->img_path) }}">
            </a>
        @endforeach
    </div>
</div>
@endslot

@endcomponent

<ul>
@foreach ($categories as $category)
    @if (count($category['child']) > 0)
        <li class="expand"><a>{{ $category['name'] }}</a>
        @include('component.nav', array('categories' => $category['child']))
        </li>
    @else
        <li><a href="{{ $category['route']}}">{{ $category['name'] }}</a></li>
    @endif
@endforeach
</ul>

{{--
<nav>
    <ul>
        <li><a href="#">Trang chủ</a></li>
        <li><a href="#">Tin tức</a></li>

        <li class="expand"><a>Cáp Quang Viettel Bình Dương</a>
            <ul>
                <li><a href="#">Cáp Quang Gia Đình</a></li>
                <li><a href="#">Cáp Quang Doanh Nghiệp</a></li>
            </ul>
        </li>

        <li class="expand"><a>Truyền Hình Cáp Viettel</a>
            <ul>
                <li><a href="#">Truyền Hình Cáp ANALOG</a></li>
                <li><a href="#">Truyền Hình Số 1 Chiều</a></li>
                <li><a href="#">Truyền Hình Số 2 Chiều</a></li>
            </ul>
        </li>

        <li class="expand"><a>Sản Phẩm & Dịch Vụ Khác</a>
            <ul>
                <li><a href="#">Chữ Ký Số (Viettel - CA)</a></li>
                <li><a href="#">Chống Trộm Xe Máy (Smart Motor Viettel)</a></li>
                <li><a href="#">Phát WIFI Di Động</a></li>
                <li><a href="#">Tivi Box- InternetTV</a></li>
                <li><a href="#">Đồng Hồ KIDDY Viettel</a></li>
            </ul>
        </li>

        <li><a href="#">Liên hệ</a></li>
    </ul>
</nav>
<li class="expand"><a></a>
   <ul>
       <li class="expand"><a></a>
           <ul>
               <li><a href="#"></a></li>
               <li><a href="#"></a></li>
           </ul>
       </li>
   </ul>
</li>
--}}

<form name="advisory-create" action="{{ route("advisory.create") }}" method="POST" >
    {{ csrf_field() }}
    <p>
        <input class="w3-input w3-border" required name="title"
               placeholder="Dịch vụ đăng ký"
               oninvalid="this.setCustomValidity('Vui lòng nhập dịch vụ muốn đăng ký')"
               oninput="setCustomValidity('')">
     </p>
     <p>
        <textarea class="w3-input w3-border" required name="address"
               placeholder="Địa chỉ lắp đặt và nội dung cần tư vấn"
               oninvalid="this.setCustomValidity('Vui lòng nhập địa chỉ và nội dung cần tư vấn')"
                  oninput="setCustomValidity('')"></textarea>
     </p>
     <p>
        <input class="w3-input w3-border" required name="name"
               placeholder="Họ tên"
               oninvalid="this.setCustomValidity('Vui lòng nhập họ tên')"
               oninput="setCustomValidity('')">
     </p>
     <p>
        <input class="w3-input w3-border" required name="email"
               placeholder="Email"
               oninvalid="this.setCustomValidity('Vui lòng nhập địa chỉ Email')"
               oninput="setCustomValidity('')">
     </p>
     <p>
        <input class="w3-input w3-border" required name="phone"
               placeholder="Điện thoại"
               oninvalid="this.setCustomValidity('Vui lòng nhập số điện thoại')"
               oninput="setCustomValidity('')">
     </p>
    <p>
        <button class="w3-button w3-black">
            <i class="fa fa-paper-plane"></i> ĐĂNG KÝ TƯ VẤN
        </button>
    </p>
</form>

<script>
    $("form[name='advisory-create']").submit(function(event){
        event.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            type: $(this).attr('method'),
            data: $(this).serialize(),
            success: function($response) {
                $("form[name='advisory-create']")[0].reset();
                alert("Đăng ký thành công !");
            }
        });
        return false;
    });
</script>
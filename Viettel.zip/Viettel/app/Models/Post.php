<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Post extends Model
{
    use SoftDeletes;
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'post';
    protected $dates = ['deleted_at'];
    protected $guarded = ['id'];

    public static function up()
    {
        // Schema table post
        Schema::create('post', function (Blueprint $table) {
            $table->increments('id');

            $table->string("title", 255);
            $table->text("content");
            $table->text("short_content");
            $table->string("icon_path", 100);
            $table->boolean("is_top")->default(false);
            $table->integer("category_id");
            $table->string("tags");

            $table->timestamps();
            $table->softDeletes();
        });
    }
}

<?php

namespace App\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Blade::if('notEmpty', function ($var) {
            return !empty($var);
        });

        Blade::if('Using', function ($var) {
            return isset($var) && !empty($var);
        });

        Blade::directive('date', function ($date) {
            return "<?php echo ($date)->format('d-m-Y'); ?>";
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}

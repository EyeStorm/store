<?php

namespace App\Providers;

use App\Repositories\Contracts\AdvertisementRepositoryInterface;
use App\Repositories\Contracts\AdvisoryRepositoryInterface;
use App\Repositories\Contracts\MenuRepositoryInterface;
use App\Repositories\Contracts\PostRepositoryInterface;
use App\Repositories\Contracts\SliderRepositoryInterface;
use App\Repositories\Eloquent\AdvertisementEloquentRepository;
use App\Repositories\Eloquent\AdvisoryEloquentRepository;
use App\Repositories\Eloquent\MenuEloquentRepository;
use App\Repositories\Eloquent\PostEloquentRepository;
use App\Repositories\Eloquent\SliderEloquentRepository;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(
            MenuRepositoryInterface::class,
            MenuEloquentRepository::class
        );

        $this->app->singleton(
            SliderRepositoryInterface::class,
            SliderEloquentRepository::class
        );

        $this->app->singleton(
            PostRepositoryInterface::class,
            PostEloquentRepository::class
        );

        $this->app->singleton(
            AdvisoryRepositoryInterface::class,
            AdvisoryEloquentRepository::class
        );

        $this->app->singleton(
            AdvertisementRepositoryInterface::class,
            AdvertisementEloquentRepository::class
        );
    }
}

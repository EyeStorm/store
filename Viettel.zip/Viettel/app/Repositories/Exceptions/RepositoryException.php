<?php

namespace App\Repositories\Exceptions;
/**
 * Class RepositoryException
 */
class RepositoryException extends \Exception
{

}

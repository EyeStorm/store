<?php
/**
 * Date: 2017-11-02
 * Time: 13:04
 */

namespace App\Repositories\Eloquent;


use App\Models\Post;
use App\Repositories\Contracts\PostRepositoryInterface;

class PostEloquentRepository extends EloquentRepository implements PostRepositoryInterface
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model() {
        return Post::class;
    }

    public function all($columns = array('*')) {
    }

    public function paginate($perPage = 15, $columns = array('*')) {
    }

    public function findBy($field, $value, $columns = array('*')) {
    }

}
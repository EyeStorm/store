<?php
/**
 * Date: 2017-11-02
 * Time: 11:43
 */

namespace App\Repositories\Eloquent;

use App\Repositories\Exceptions\RepositoryException;
use Illuminate\Container\Container as App;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use PHPUnit\Runner\Exception;

abstract class EloquentRepository
{
    /**
     * @var App
     */
    private $app;

    /**
     * @var
     */
    protected $model;

    /**
     * @var
     */
    protected $modelWithTrashed;

    /**
     * @var
     */
    protected $softDelete;

    /**
     * @param App $app
     * @throws RepositoryException
     */
    public function __construct(App $app) {
        $this->app = $app;
        $this->makeModel();
    }

    /**
     * Specify Model class name
     *
     * @return mixed
     */
    abstract function model();

    /**
     * @return Model
     * @throws RepositoryException
     */
    public function makeModel() {
        $model = $this->app->make($this->model());

        if (!$model instanceof Model)
            throw new RepositoryException("Class {$this->model()} must be an instance of Illuminate\\Database\\Eloquent\\Model");

        $this->softDelete = in_array(SoftDeletes::class, class_uses($model));
        if ( $this->softDelete ) {
            $this->modelWithTrashed = $this->app->make($this->model())::withTrashed();
        }

        return $this->model = $model;
    }

    /**
     * @param bool $withTrashed
     * @return mixed
     */
    protected function getMode($withTrashed = true) {
        $model = $this->model;
        if ( $withTrashed && $this->softDelete ) {
            $model = $this->modelWithTrashed;
        }
        return $model;
    }

    /**
     * @param bool $withTrashed
     * @return mixed
     */
    public function cloneMode($withTrashed = true) {
        $model = clone  $this->model;
        if ( $withTrashed && $this->softDelete ) {
            $model = clone $this->modelWithTrashed;
        }
        return $model;
    }

    /**
     * @param $id
     * @param array $columns
     * @return mixed
     */
    public function find($id, $columns = array('*')) {
        return $this->getMode()->select($columns)->find($id);
    }

    /**
     * Delete
     *
     * @param $id
     * @return bool
     */
    public function delete($id, $force = false)
    {
        $handleMode = $this->model;
        if ( $this->softDelete ) {
            $handleMode = $handleMode->withTrashed();
        }
        $result = $handleMode->find($id);
        if($result) {
            if ( $this->softDelete && $force) {
                $result->forceDelete();
            } else {
                $result->delete();
            }
            return true;
        }
        return false;
    }

    /**
     * Restore
     *
     * @param $id
     * @return bool
     * @throws RepositoryException
     */
    public function restore($id)
    {
        if ( ! $this->softDelete ) {
            throw new RepositoryException("Class {$this->model()} dose not support SoftDelete");
        }

        $result = $this->model->withTrashed()->find($id);
        if($result) {
            $result->restore();
            return true;
        }
        return false;
    }

    /**
     * @param array $data
     */
    public function create(array $data) {
        $this->fill($data)->save();
    }

    /**
     * @param array $data
     * @param $id
     */
    public function update(array $data, $id) {
        $targetItem = $this->cloneMode()->find($id);
        $this->fill($data, $targetItem)->save();
    }

    /**
     * @param array $data
     */
    public function updates(array $data) {
        if (count($data) == 0) {
            return;
        }
        foreach ($data as $item) {
            if ( isset($item['id']) ) {
                $this->update($item, $item['id']);
                continue;
            }
            $this->create($item);
        }
    }

    /**
     * @param array $data
     * @param Model|null $target
     * @return Model
     * @throws RepositoryException
     */
    public function fill(array $data,Model $target = null)
    {
        $cloneModel = $target;
        if ( $target === null ) {
            $cloneModel = $this->cloneMode(false);
        }
        try {
            $cloneModel->fill($data);
        } catch(Exception $ex) {
            throw new RepositoryException("Class {$this->model()} may not enough rule ! Please check {\$fillable} or {\$guarded} variable");
        }
        return $cloneModel;
    }
}
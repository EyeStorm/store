<?php
/**
 * User: huan-tn
 * Date: 2017-11-02
 * Time: 13:04
 */

namespace App\Repositories\Eloquent;

use App\Models\Advertisement;
use App\Repositories\Contracts\AdvertisementRepositoryInterface;

class AdvertisementEloquentRepository extends EloquentRepository implements AdvertisementRepositoryInterface
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model() {
        return Advertisement::class;
    }

    public function all($columns = array('*')) {
    }

    public function paginate($perPage = 15, $columns = array('*')) {
    }

    public function find($id, $columns = array('*')) {
    }

    public function findBy($field, $value, $columns = array('*')) {
    }

}
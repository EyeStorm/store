<?php
/**
 * User: huan-tn
 * Date: 2017-11-02
 * Time: 11:03
 */

namespace App\Repositories\Contracts;

use Illuminate\Database\Eloquent\Model;

interface RepositoryInterface
{
    public function all($columns = array('*'));

    public function paginate($perPage = 15, $columns = array('*'));

    public function find($id, $columns = array('*'));

    public function findBy($field, $value, $columns = array('*'));

    public function create(array $data);

    public function update(array $data, $id);

    public function updates(array $data);

    public function delete($id);

    public function restore($id);

    public function fill(array $data,Model $target = null);

}
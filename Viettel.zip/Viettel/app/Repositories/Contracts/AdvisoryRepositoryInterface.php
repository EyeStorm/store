<?php
/**
 * User: huan-tn
 * Date: 2017-11-02
 * Time: 11:03
 */

namespace App\Repositories\Contracts;

interface AdvisoryRepositoryInterface extends RepositoryInterface{}
<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Contracts\SimpleController;
use App\Repositories\Contracts\MenuRepositoryInterface;

class CategoryController extends SimpleController
{
    // Constructor
    public function __construct(MenuRepositoryInterface $menu) {
        $this->model = $menu;
        $this->item = "menu";
        $this->items = "menus";
    }
}

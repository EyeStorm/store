<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Contracts\SimpleController;
use App\Repositories\Contracts\PostRepositoryInterface;
use Illuminate\Support\Facades\DB;

class PostController extends SimpleController
{
    // Constructor
    public function __construct(PostRepositoryInterface $post) {
        $this->model = $post;
        $this->item = "post";
        $this->items = "posts";
    }

    /**
     * Get list
     */

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function byRoute($id)
    {
        $posts = DB::table('post')
            ->where('category_id', '=', $id)
            ->get();
        return view('admin.component.post-list', ['posts' => $posts]);
    }

}

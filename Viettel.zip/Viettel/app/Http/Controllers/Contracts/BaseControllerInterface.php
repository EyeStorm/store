<?php
/**
 * Date: 11/08/2017
 * Time: 20:30
 */

namespace App\Http\Controllers\Contracts;

interface BaseControllerInterface
{
    public function get($id);

    public function save();

    public function create();

    public function update();

    public function delete($id);

    public function restore($id);
}
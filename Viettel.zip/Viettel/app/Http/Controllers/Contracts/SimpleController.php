<?php
/**
 * Date: 11/08/2017
 * Time: 22:29
 */

namespace App\Http\Controllers\Contracts;

use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Input;

abstract class SimpleController extends Controller implements BaseControllerInterface
{
    // Constructor
    protected $model;
    protected $item;
    protected $items;

    public function get($id)
    {
        return response($this->model->find($id)->toJson());
    }

    public function save()
    {
        $id = Input::get("id");
        if ( $id === null || $id === 0) {
            $this->model->create(Input::all());
        } else {
            $this->model->update(Input::all(), $id);
        }
        return response()->json([
            "success"=> true
        ]);
    }

    public function create()
    {
        $this->model->create(Input::all());
        return response()->json([
            "success"=> true
        ]);
    }

    public function update()
    {
        $data = Input::get($this->items);
        $this->model->updates($data);
        return response()->json([
            "success"=> true
        ]);
    }

    public function delete($id) {
        $force = Input::has('force');
        return response()->json([
            "success"=> $this->model->delete($id, $force)
        ]);
    }

    public function restore($id)
    {
        return response()->json([
            "success"=> $this->model->restore($id)
        ]);
    }

}
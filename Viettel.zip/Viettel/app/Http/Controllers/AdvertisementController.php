<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Contracts\SimpleController;
use App\Repositories\Contracts\AdvertisementRepositoryInterface;

class AdvertisementController extends SimpleController
{
    // Constructor
    public function __construct(AdvertisementRepositoryInterface $advertisement) {
        $this->model = $advertisement;
        $this->item = "advertisement";
        $this->items = "advertisements";
    }
}

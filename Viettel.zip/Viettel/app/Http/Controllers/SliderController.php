<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Contracts\SimpleController;
use App\Repositories\Contracts\SliderRepositoryInterface;

class SliderController extends SimpleController
{
    // Constructor
    public function __construct(SliderRepositoryInterface $slider) {
        $this->model = $slider;
        $this->item = "slider";
        $this->items = "sliders";
    }
}

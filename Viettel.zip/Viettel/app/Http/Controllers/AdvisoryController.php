<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Contracts\SimpleController;
use App\Repositories\Contracts\AdvisoryRepositoryInterface;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

class AdvisoryController extends SimpleController
{
    // Constructor
    public function __construct(AdvisoryRepositoryInterface $advisory) {
        $this->model = $advisory;
        $this->item = "advisory";
        $this->items = "advisories";
    }

    public function byDate($date)
    {
        $advisories = DB::table('advisory')
            ->where(DB::raw("DATE(created_at)"), '=', date("Y-m-d", strtotime($date)))
            ->orderBy('processed')
            ->get();

        return view('admin.component.newfeed-list', ['advisories' => $advisories]);
    }

    public function doAdvised($id)
    {
        $this->model->update(Input::all(),$id);
        return response()->json([
            "success"=> true
        ]);
    }

}

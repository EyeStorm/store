<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class NewsController extends BaseController
{
    /**
     * Show news list
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Get news for content
        $aryNews = Post::where('category_id', '=', '1')
            ->orderBy('created_at', 'desc')
            ->paginate(9);
        return view('news.index', ['aryNews' => $aryNews]);
    }
    /**
     * Show news detail
     *
     * @return \Illuminate\Http\Response
     */
    public function detail(Request $request)
    {
        // Get id news
        $id = $request->input('id');
        // Get news info
        $aryNews = null;
        if ($id != null) {
            $aryNews = Post::where('id', '=', $id)
                ->where('category_id', '=', '1')
                ->get();
        }
        // Get random other news
        $aryOther = null;
        if ($aryNews != null && $aryNews[0]->created_at != null) {
            $aryOther = Post::where('category_id', '=', '1')
                ->where('created_at', '<=', $aryNews[0]->created_at)
                ->orderBy('created_at', 'desc')
                ->limit(10)->get();
        } else {
            $aryOther = Post::where('category_id', '=', '1')
                ->orderBy('created_at', 'desc')
                ->limit(10)->get();
        }
        return view('news.detail', ['aryNews' => $aryNews, 'aryOther' => $aryOther]);
    }
}

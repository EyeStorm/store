<?php

namespace App\Http\Controllers;

use App\Models\Advertisement;
use App\Models\Category;
use App\Models\Post;
use App\Models\Slider;
use Illuminate\Support\Facades\View;

class BaseController extends Controller
{
    public function __construct() {
        // Get category for header
        $aryCategory = Category::where('show_category_child', '=', '0')
            ->with('PostsForHeader')
            ->orderBy('priority')
            ->orderBy('created_at', 'desc')
            ->get();
        View::share('aryCategory', $aryCategory);

        // Get slider for header
        $arySlider = Slider::orderBy('priority')->get();
        View::share('arySlider', $arySlider);

        // Get news top for content
        $aryNewsTop = Post::where('category_id', '=', '1')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        View::share('aryNewsTop', $aryNewsTop);
        
        // Get services top for content
        $aryServicesTop = Post::where('category_id', '<>', '1')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        View::share('aryServicesTop', $aryServicesTop);

        // Get advertisement for content
        $aryAdvertisement = Advertisement::get();
        View::share('aryAdvertisement', $aryAdvertisement);
    }
}

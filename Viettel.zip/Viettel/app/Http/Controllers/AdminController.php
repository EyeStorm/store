<?php

namespace App\Http\Controllers;

use App\Models\Advertisement;
use App\Models\Advisory;
use App\Models\Category;
use App\Models\Slider;
use App\Repositories\Contracts\MenuRepositoryInterface;
use App\Repositories\Contracts\PostRepositoryInterface;
use App\Repositories\Contracts\SliderRepositoryInterface;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;

class AdminController extends BaseController
{
    // Constructor
    private $slider;
    private $menu;
    private $post;
    public function __construct(
        SliderRepositoryInterface    $slider,
        MenuRepositoryInterface      $menu,
        PostRepositoryInterface      $post
    ) {
        $this->slider   = $slider;
        $this->menu     = $menu;
        $this->post     = $post;
    }

    public function index()
    {
        // Tag1
        // Tag2
        $menus = Category::withTrashed()
            ->orderBy('deleted_at')
            ->orderBy('priority')
            ->get();
        // Tag3
        $sliders = Slider::withTrashed()
            ->orderBy('deleted_at')
            ->orderBy('priority')
            ->get();
        // Tag4
        $advertisements = Advertisement::withTrashed()
            ->orderBy('deleted_at')
            ->orderBy('priority')
            ->get();
        // Tag5
        $advisories = Advisory::withTrashed()
            ->select('created_at')
            ->groupBy(DB::raw("DATE(created_at)"))
            ->orderBy('created_at', "DESC")
            ->get();

        return view('admin.index', [
            'menus'      => $menus,
            "sliders"    => $sliders,
            "newfeeds"   => $advertisements,
            "advisories" => $advisories
        ]);
    }

    public function index1()
    {
        $menu = [];
        $categories = DB::table('category')
            ->where('parent_id', '=', 0)
            ->get();
        $this->PopulateMenu($categories, $menu);
    }
    protected function PopulateMenu($categories, &$menuItem)
    {
        foreach ($categories as $category) {
            $newItem = [
                'id' => $category->id,
                'route' => $category->route,
                'name'  => $category->name,
                'parent_id'  => $category->parent_id,
                'child' => [],
            ];
            $menuItem[$category->id] = $newItem;

            $nextChildCategory = DB::table('category')
                                ->where('parent_id', '=', $category->id)
                                ->get();
            if (sizeof($nextChildCategory) > 0) {
                $this->PopulateMenu($nextChildCategory, $menuItem[$category->id]['child']);
            }
        }
    }

}

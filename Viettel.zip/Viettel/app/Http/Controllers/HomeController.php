<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class HomeController extends BaseController
{
    /**
     * Show homepage/service list
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Get services for content
        $aryServices = Post::where('category_id', '<>', '1')
            ->orderBy('updated_at', 'asc')
            ->paginate(9);
        return view('home.index', ['aryServices' => $aryServices]);
    }
    /**
     * Show service detail
     *
     * @return \Illuminate\Http\Response
     */
    public function detail(Request $request)
    {
        // Get id service
        $id = $request->input('id');
        // Get service info
        $aryService = null;
        if ($id != null) {
            $aryService = Post::where('id', '=', $id)
                                ->where('category_id', '<>', '1')
                                ->first();
        }
        // Get random other service
        $aryOther = Post::where('category_id', '<>', '1')->inRandomOrder()->limit(4)->get();
        return view('home.detail', ['aryService' => $aryService, 'aryOther' => $aryOther]);
    }
    /**
     * Show contact
     *
     * @return \Illuminate\Http\Response
     */
    public function contact(Request $request)
    {
        $url = $request->fullUrl();
        $urlData = explode('?', $url);
        $location = 'thu-dau-mot';
        if ( sizeof($urlData) == 2 ) {
            $location = $location[1];
        }
        return view('home.contact',['location' => $location]);
    }
}
